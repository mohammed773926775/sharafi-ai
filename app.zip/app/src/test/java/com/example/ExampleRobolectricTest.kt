package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.sharafi.domain.executor.SystemActionExecutor
import com.example.sharafi.domain.nlu.ExecutionOutcomeStatus
import com.example.sharafi.domain.nlu.SharafiNluEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `verify app name and local system executor telemetry on Android context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SHARAFI AI", appName)

        val nlu = SharafiNluEngine()
        val executor = SystemActionExecutor(context)

        // Verify battery telemetry execution
        val batteryIntent = nlu.analyzeUtterance("كم نسبة البطارية").intents.first()
        val batteryRes = executor.executeIntent(batteryIntent, requireSensitiveConfirmation = true)
        assertEquals(ExecutionOutcomeStatus.VERIFIED_SUCCESS, batteryRes.status)
        assertTrue(batteryRes.spokenResponseAr.contains("بالمئة"))

        // Verify sensitive call confirmation gate
        val callIntent = nlu.analyzeUtterance("Call 0509988776").intents.first()
        val unconfirmedRes = executor.executeIntent(
            intent = callIntent,
            requireSensitiveConfirmation = true,
            userConfirmedSensitive = false
        )
        assertEquals(ExecutionOutcomeStatus.AWAITING_CONFIRMATION, unconfirmedRes.status)
    }
}
