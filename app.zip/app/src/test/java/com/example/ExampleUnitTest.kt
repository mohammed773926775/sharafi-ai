package com.example

import com.example.sharafi.data.CustomCommandEntity
import com.example.sharafi.domain.nlu.AssistantLanguage
import com.example.sharafi.domain.nlu.SharafiNluEngine
import com.example.sharafi.domain.nlu.TextNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    private val nluEngine = SharafiNluEngine()

    @Test
    fun `arabic normalization converts alef variants, taa marbuta, eastern digits and number words`() {
        val raw = "يا شرافي إرفع الصوت إلى ٨٠ بالمئة"
        val normalized = TextNormalizer.normalize(raw)
        assertTrue(normalized.contains("ارفع الصوت الي 80"))
        assertEquals(80, TextNormalizer.extractFirstNumber(normalized))
    }

    @Test
    fun `multi-action splitter separates compound arabic and english commands`() {
        val arabicCompound = "شغل الفلاش ثم ارفع الصوت الى 70 وبعدين كم نسبة البطارية"
        val arSegments = TextNormalizer.splitMultiActionCommands(arabicCompound)
        assertEquals(3, arSegments.size)

        val englishCompound = "Turn on flashlight and then set volume to 60 then what is the battery level"
        val enSegments = TextNormalizer.splitMultiActionCommands(englishCompound)
        assertEquals(3, enSegments.size)
    }

    @Test
    fun `bilingual nlu classifies hardware, audio, alarm, telemetry and math intents`() {
        val arFlash = nluEngine.analyzeUtterance("من فضلك نور الكشاف الخلفي")
        assertEquals(AssistantLanguage.AR, arFlash.detectedLanguage)
        assertEquals("FLASHLIGHT_ON", arFlash.intents.first().actionId)

        val enFlashOff = nluEngine.analyzeUtterance("Could you turn off the torch")
        assertEquals(AssistantLanguage.EN, enFlashOff.detectedLanguage)
        assertEquals("FLASHLIGHT_OFF", enFlashOff.intents.first().actionId)

        val arAlarm = nluEngine.analyzeUtterance("صحيني الساعة سبعة ونصف صباحاً")
        assertEquals("SET_ALARM", arAlarm.intents.first().actionId)
        assertEquals("7", arAlarm.intents.first().parameters["hour"])
        assertEquals("30", arAlarm.intents.first().parameters["minute"])

        val enCalc = nluEngine.analyzeUtterance("Calculate 25 times 4")
        assertEquals("CALCULATE_EXPRESSION", enCalc.intents.first().actionId)
        assertEquals("25", enCalc.intents.first().parameters["lhs"])
        assertEquals("4", enCalc.intents.first().parameters["rhs"])
    }

    @Test
    fun `custom macro expands into multiple sequential intents`() {
        val customMacros = listOf(
            CustomCommandEntity(
                id = 7L,
                title = "وضع النوم",
                triggerPhrases = "وضع النوم, sleep mode",
                actionPipeline = "اطفئ الكشاف ثم وضع الصامت ثم كم نسبة البطارية",
                description = "Test macro"
            )
        )

        val result = nluEngine.analyzeUtterance("فعل وضع النوم", enabledCustomCommands = customMacros)
        assertEquals(7L, result.matchedCustomCommandId)
        assertEquals(3, result.intents.size)
        assertEquals("FLASHLIGHT_OFF", result.intents[0].actionId)
        assertEquals("RINGER_SILENT", result.intents[1].actionId)
        assertEquals("QUERY_BATTERY", result.intents[2].actionId)
    }

    @Test
    fun `ambiguous command triggers clarification and resolves on follow-up`() {
        val ambiguousAlarm = nluEngine.analyzeUtterance("اضبط منبه")
        val pendingIntent = ambiguousAlarm.intents.first()
        assertTrue(pendingIntent.requiresClarification)
        assertNotNull(pendingIntent.clarificationPromptAr)

        val resolved = nluEngine.analyzeUtterance(
            rawUtterance = "الساعة 6 صباحا",
            pendingClarification = pendingIntent
        )
        val finalIntent = resolved.intents.first()
        assertFalse(finalIntent.requiresClarification)
        assertEquals("SET_ALARM", finalIntent.actionId)
        assertEquals("6", finalIntent.parameters["hour"])
    }

    @Test
    fun `sensitive actions require confirmation and unsafe shell commands are blocked`() {
        val callIntent = nluEngine.analyzeUtterance("اتصل بالرقم 0501234567").intents.first()
        assertEquals("CALL_NUMBER", callIntent.actionId)
        assertTrue(callIntent.isSensitive)

        val blockedShell = nluEngine.analyzeUtterance("su -c rm -rf /system/bin").intents.first()
        assertEquals("BLOCKED_UNSAFE_SHELL", blockedShell.actionId)
    }
}
