package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val SharafiDarkColorScheme = darkColorScheme(
    primary = CyanGlow,
    onPrimary = Color(0xFF002A32),
    primaryContainer = CyanContainer,
    onPrimaryContainer = CyanBright,
    secondary = TurquoiseAccent,
    onSecondary = Color(0xFF00281E),
    secondaryContainer = TurquoiseContainer,
    onSecondaryContainer = TurquoiseAccent,
    tertiary = ElectricBlue,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF0B254E),
    onTertiaryContainer = Color(0xFF90CAF9),
    background = ObsidianDeep,
    onBackground = TextPrimary,
    surface = ObsidianSurface,
    onSurface = TextPrimary,
    surfaceVariant = ObsidianCard,
    onSurfaceVariant = TextSecondary,
    surfaceContainerHigh = ObsidianElevated,
    outline = BorderSubtle,
    outlineVariant = Color(0xFF15273E),
    error = CoralDanger,
    onError = Color.White,
    errorContainer = CoralContainer,
    onErrorContainer = Color(0xFFFFB4AB)
)

val SharafiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MyApplicationTheme(
    isArabicUi: Boolean = false,
    content: @Composable () -> Unit
) {
    val layoutDirection = if (isArabicUi) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        MaterialTheme(
            colorScheme = SharafiDarkColorScheme,
            typography = sharafiTypography(isArabic = isArabicUi),
            shapes = SharafiShapes,
            content = content
        )
    }
}
