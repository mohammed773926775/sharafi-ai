package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SHARAFI AI Futuristic Acoustic HUD Palette
val ObsidianDeep = Color(0xFF060D18)
val ObsidianSurface = Color(0xFF0C1726)
val ObsidianCard = Color(0xFF112036)
val ObsidianElevated = Color(0xFF172B47)

val CyanGlow = Color(0xFF00E5FF)
val CyanBright = Color(0xFF6EFFFF)
val CyanDim = Color(0xFF006978)
val CyanContainer = Color(0xFF083244)

val TurquoiseAccent = Color(0xFF1DE9B6)
val TurquoiseDim = Color(0xFF008663)
val TurquoiseContainer = Color(0xFF06372E)

val ElectricBlue = Color(0xFF2979FF)
val AmberAlert = Color(0xFFFFAB00)
val AmberContainer = Color(0xFF3E2B00)
val CoralDanger = Color(0xFFFF5252)
val CoralContainer = Color(0xFF3F1218)
val EmeraldSuccess = Color(0xFF00E676)

val TextPrimary = Color(0xFFEAF6FF)
val TextSecondary = Color(0xFF93B3CC)
val TextMuted = Color(0xFF5D7C96)
val BorderSubtle = Color(0xFF1E3756)
