package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesomeMotion
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sharafi.domain.nlu.AssistantLanguage
import com.example.sharafi.service.SharafiVoiceService
import com.example.sharafi.ui.SharafiScreen
import com.example.sharafi.ui.SharafiViewModel
import com.example.sharafi.ui.screens.CapabilitiesPermissionsScreen
import com.example.sharafi.ui.screens.CommandCenterScreen
import com.example.sharafi.ui.screens.CommandHistoryScreen
import com.example.sharafi.ui.screens.CustomCommandsScreen
import com.example.sharafi.ui.screens.VoiceSettingsAndInfoScreen
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianDeep
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: SharafiViewModel = viewModel(
                factory = SharafiViewModel.Factory(application)
            )
            val settings by viewModel.settingsState.collectAsStateWithLifecycle()
            val isArabic = settings.uiLanguage == "AR"

            MyApplicationTheme(isArabicUi = isArabic) {
                SharafiMainApp(
                    viewModel = viewModel,
                    isArabic = isArabic
                )
            }
        }
    }
}

private data class NavDestinationItem(
    val screen: SharafiScreen,
    val labelAr: String,
    val labelEn: String,
    val icon: ImageVector,
    val tag: String
)

@Composable
fun SharafiMainApp(
    viewModel: SharafiViewModel,
    isArabic: Boolean
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val settings by viewModel.settingsState.collectAsStateWithLifecycle()
    val history by viewModel.historyState.collectAsStateWithLifecycle()
    val customCommands by viewModel.customCommandsState.collectAsStateWithLifecycle()
    val consoleState by viewModel.consoleState.collectAsStateWithLifecycle()
    val capabilities by viewModel.capabilitiesSnapshot.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()

    val listeningState by viewModel.speechEngine.listeningState.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.speechEngine.partialTranscript.collectAsStateWithLifecycle()
    val rmsAmplitude by viewModel.speechEngine.rmsAmplitude.collectAsStateWithLifecycle()
    val engineStatusMessage by viewModel.speechEngine.engineStatusMessage.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.ttsEngine.isSpeaking.collectAsStateWithLifecycle()
    val ttsDiagnostic by viewModel.ttsEngine.ttsDiagnostic.collectAsStateWithLifecycle()
    val isForegroundServiceRunning by SharafiVoiceService.isRunning.collectAsStateWithLifecycle()

    // Refresh capabilities when returning from system settings screens
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshCapabilities()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshCapabilities()
        if (granted) {
            viewModel.startOrStopMicrophoneListening()
        }
    }

    val callPhonePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshCapabilities()
    }

    val notificationsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshCapabilities()
    }

    val destinations = listOf(
        NavDestinationItem(
            screen = SharafiScreen.COMMAND_CENTER,
            labelAr = "المركز",
            labelEn = "Assistant",
            icon = Icons.Default.Mic,
            tag = "nav_command_center"
        ),
        NavDestinationItem(
            screen = SharafiScreen.HISTORY,
            labelAr = "السجل",
            labelEn = "History",
            icon = Icons.Default.History,
            tag = "nav_history"
        ),
        NavDestinationItem(
            screen = SharafiScreen.CUSTOM_MACROS,
            labelAr = "الأوامر",
            labelEn = "Macros",
            icon = Icons.Default.AutoAwesomeMotion,
            tag = "nav_macros"
        ),
        NavDestinationItem(
            screen = SharafiScreen.CAPABILITIES,
            labelAr = "القدرات",
            labelEn = "System",
            icon = Icons.Default.Security,
            tag = "nav_capabilities"
        ),
        NavDestinationItem(
            screen = SharafiScreen.SETTINGS_INFO,
            labelAr = "الإعدادات",
            labelEn = "Settings",
            icon = Icons.Default.Tune,
            tag = "nav_settings"
        )
    )

    val handleMicrophoneTrigger = {
        val hasAudioPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (hasAudioPerm) {
            viewModel.startOrStopMicrophoneListening()
        } else {
            recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = ObsidianDeep,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!isWideScreen) {
                    NavigationBar(
                        containerColor = ObsidianSurface,
                        contentColor = TextPrimary
                    ) {
                        destinations.forEach { dest ->
                            val selected = currentScreen == dest.screen
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.navigateTo(dest.screen) },
                                icon = {
                                    Icon(
                                        imageVector = dest.icon,
                                        contentDescription = if (isArabic) dest.labelAr else dest.labelEn
                                    )
                                },
                                label = {
                                    Text(
                                        text = if (isArabic) dest.labelAr else dest.labelEn,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyanGlow,
                                    selectedTextColor = CyanGlow,
                                    indicatorColor = CyanContainer,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag(dest.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isWideScreen) {
                    NavigationRail(
                        containerColor = ObsidianSurface,
                        contentColor = TextPrimary
                    ) {
                        destinations.forEach { dest ->
                            val selected = currentScreen == dest.screen
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.navigateTo(dest.screen) },
                                icon = {
                                    Icon(
                                        imageVector = dest.icon,
                                        contentDescription = if (isArabic) dest.labelAr else dest.labelEn
                                    )
                                },
                                label = {
                                    Text(text = if (isArabic) dest.labelAr else dest.labelEn)
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CyanGlow,
                                    selectedTextColor = CyanGlow,
                                    indicatorColor = CyanContainer,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag(dest.tag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (currentScreen) {
                        SharafiScreen.COMMAND_CENTER -> CommandCenterScreen(
                            isArabic = isArabic,
                            settings = settings,
                            listeningState = listeningState,
                            partialTranscript = partialTranscript,
                            rmsAmplitude = rmsAmplitude,
                            engineStatusMessage = engineStatusMessage,
                            isSpeaking = isSpeaking,
                            consoleState = consoleState,
                            capabilities = capabilities,
                            recentHistory = history,
                            onMicClick = handleMicrophoneTrigger,
                            onExecuteCommand = { cmd -> viewModel.processVoiceOrTextCommand(cmd) },
                            onToggleLanguage = { viewModel.toggleUiLanguage() },
                            onToggleVoiceResponses = { enabled -> viewModel.setVoiceResponsesEnabled(enabled) },
                            onReplayResponse = {
                                viewModel.ttsEngine.speakOffline(
                                    text = consoleState.combinedAssistantResponse,
                                    language = consoleState.detectedLanguage,
                                    enabled = true,
                                    rate = settings.speechRate,
                                    pitch = settings.speechPitch
                                )
                            },
                            onConfirmSensitiveAction = { viewModel.confirmPendingSensitiveAction() },
                            onCancelSensitiveAction = { viewModel.cancelPendingSensitiveAction() },
                            onDismissClarification = { viewModel.dismissClarification() },
                            onViewAllHistory = { viewModel.navigateTo(SharafiScreen.HISTORY) }
                        )

                        SharafiScreen.HISTORY -> CommandHistoryScreen(
                            isArabic = isArabic,
                            historyItems = history,
                            onReExecuteCommand = { cmd -> viewModel.processVoiceOrTextCommand(cmd) },
                            onToggleFavorite = { item -> viewModel.toggleHistoryFavorite(item) },
                            onDeleteItem = { id -> viewModel.deleteHistoryItem(id) },
                            onClearAll = { viewModel.clearAllHistory() },
                            onBackToCenter = { viewModel.navigateTo(SharafiScreen.COMMAND_CENTER) }
                        )

                        SharafiScreen.CUSTOM_MACROS -> CustomCommandsScreen(
                            isArabic = isArabic,
                            customCommands = customCommands,
                            onSaveCommand = { id, title, triggers, pipeline, desc ->
                                viewModel.saveCustomCommand(id, title, triggers, pipeline, desc)
                            },
                            onToggleEnabled = { cmd -> viewModel.toggleCustomCommandEnabled(cmd) },
                            onDeleteCommand = { id -> viewModel.deleteCustomCommand(id) },
                            onRunMacroNow = { cmd ->
                                val firstTrigger = cmd.triggerPhrases.split(",", "،").firstOrNull()?.trim()
                                    ?: cmd.actionPipeline
                                viewModel.processVoiceOrTextCommand(firstTrigger)
                            },
                            onBackToCenter = { viewModel.navigateTo(SharafiScreen.COMMAND_CENTER) }
                        )

                        SharafiScreen.CAPABILITIES -> CapabilitiesPermissionsScreen(
                            isArabic = isArabic,
                            capabilities = capabilities,
                            installedApps = installedApps,
                            registeredModules = viewModel.getRegisteredModules(),
                            onRequestRecordAudioPermission = {
                                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            },
                            onRequestCallPhonePermission = {
                                callPhonePermissionLauncher.launch(Manifest.permission.CALL_PHONE)
                            },
                            onRequestNotificationsPermission = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationsPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            onRefreshCapabilities = { viewModel.refreshCapabilities() },
                            onExecuteSampleCommand = { cmd -> viewModel.processVoiceOrTextCommand(cmd) },
                            onBackToCenter = { viewModel.navigateTo(SharafiScreen.COMMAND_CENTER) }
                        )

                        SharafiScreen.SETTINGS_INFO -> VoiceSettingsAndInfoScreen(
                            isArabic = isArabic,
                            settings = settings,
                            isForegroundServiceRunning = isForegroundServiceRunning,
                            ttsDiagnostic = ttsDiagnostic,
                            onToggleUiLanguage = { viewModel.toggleUiLanguage() },
                            onSelectRecognitionMode = { mode -> viewModel.setRecognitionLanguageMode(mode) },
                            onToggleVoiceResponses = { enabled -> viewModel.setVoiceResponsesEnabled(enabled) },
                            onSpeechRateChange = { rate -> viewModel.setSpeechRate(rate) },
                            onSpeechPitchChange = { pitch -> viewModel.setSpeechPitch(pitch) },
                            onToggleStrictOffline = { strict -> viewModel.setStrictOfflineRecognition(strict) },
                            onToggleSensitiveGuard = { guard -> viewModel.setRequireSensitiveConfirmation(guard) },
                            onToggleHaptics = { haptics -> viewModel.setHapticFeedbackEnabled(haptics) },
                            onToggleBackgroundService = { enable ->
                                if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    val notifGranted = ContextCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.POST_NOTIFICATIONS
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (!notifGranted) {
                                        notificationsPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }
                                viewModel.toggleBackgroundVoiceService(enable)
                            },
                            onTestTtsVoice = { viewModel.testVoiceSynthesisSample() },
                            onBackToCenter = { viewModel.navigateTo(SharafiScreen.COMMAND_CENTER) }
                        )
                    }
                }
            }
        }
    }
}
