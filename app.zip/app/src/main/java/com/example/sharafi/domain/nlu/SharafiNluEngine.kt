package com.example.sharafi.domain.nlu

import com.example.sharafi.data.CustomCommandEntity
import com.example.sharafi.domain.nlu.modules.AccessibilityNavPlugin
import com.example.sharafi.domain.nlu.modules.AlarmsTimersPlugin
import com.example.sharafi.domain.nlu.modules.AppManagementPlugin
import com.example.sharafi.domain.nlu.modules.AudioVolumePlugin
import com.example.sharafi.domain.nlu.modules.CameraMediaPlugin
import com.example.sharafi.domain.nlu.modules.CommunicationPlugin
import com.example.sharafi.domain.nlu.modules.DeviceTelemetryPlugin
import com.example.sharafi.domain.nlu.modules.HardwareFlashlightPlugin
import com.example.sharafi.domain.nlu.modules.SystemSettingsPlugin
import com.example.sharafi.domain.nlu.modules.UtilityCalculatorPlugin

data class NluAnalysisResult(
    val rawUtterance: String,
    val detectedLanguage: AssistantLanguage,
    val intents: List<ParsedCommandIntent>,
    val matchedCustomCommandId: Long? = null,
    val matchedCustomCommandTitle: String? = null
)

class SharafiNluEngine {

    private val registeredPlugins = mutableListOf<CommandModulePlugin>()

    init {
        // Order prioritizes specific hardware/telemetry/settings modules before generic open-app fallback
        registerPlugin(HardwareFlashlightPlugin())
        registerPlugin(AudioVolumePlugin())
        registerPlugin(AlarmsTimersPlugin())
        registerPlugin(CameraMediaPlugin())
        registerPlugin(CommunicationPlugin())
        registerPlugin(DeviceTelemetryPlugin())
        registerPlugin(AccessibilityNavPlugin())
        registerPlugin(UtilityCalculatorPlugin())
        registerPlugin(SystemSettingsPlugin())
        registerPlugin(AppManagementPlugin())
    }

    fun registerPlugin(plugin: CommandModulePlugin) {
        registeredPlugins.removeAll { it.pluginId == plugin.pluginId }
        registeredPlugins.add(plugin)
    }

    fun getRegisteredPlugins(): List<CommandModulePlugin> = registeredPlugins.toList()

    /**
     * Analyzes a raw voice or text utterance, checking custom commands first,
     * splitting multi-action chains, and classifying each segment into validated intents.
     */
    fun analyzeUtterance(
        rawUtterance: String,
        enabledCustomCommands: List<CustomCommandEntity> = emptyList(),
        pendingClarification: ParsedCommandIntent? = null
    ): NluAnalysisResult {
        val detectedLang = TextNormalizer.detectLanguage(rawUtterance)
        val fullNormalized = TextNormalizer.normalize(rawUtterance)

        // 1. Security Guard: Reject any attempt to run shell commands or arbitrary code
        if (isBlockedShellOrCodeAttempt(fullNormalized)) {
            return NluAnalysisResult(
                rawUtterance = rawUtterance,
                detectedLanguage = detectedLang,
                intents = listOf(
                    ParsedCommandIntent(
                        pluginId = "security_guard",
                        actionId = "BLOCKED_UNSAFE_SHELL",
                        category = CommandCategory.UNKNOWN,
                        rawSegment = rawUtterance,
                        normalizedSegment = fullNormalized,
                        language = detectedLang
                    )
                )
            )
        }

        // 2. If there is a pending clarification question, attempt to merge the user's answer with the pending intent
        if (pendingClarification != null) {
            val resolvedFromClarification = resolveClarificationFollowUp(
                pendingIntent = pendingClarification,
                followUpRaw = rawUtterance,
                followUpNormalized = fullNormalized,
                language = detectedLang
            )
            if (resolvedFromClarification != null) {
                return NluAnalysisResult(
                    rawUtterance = rawUtterance,
                    detectedLanguage = detectedLang,
                    intents = listOf(resolvedFromClarification)
                )
            }
        }

        // 3. Check User-Defined Custom Commands (Macros)
        for (customCmd in enabledCustomCommands) {
            val triggers = customCmd.triggerPhrases
                .split(",", "،", ";")
                .map { TextNormalizer.normalize(it) }
                .filter { it.isNotBlank() }

            val isTriggered = triggers.any { trigger ->
                fullNormalized == trigger ||
                    fullNormalized.contains(trigger) && trigger.length >= 4
            }

            if (isTriggered) {
                val expandedSegments = TextNormalizer.splitMultiActionCommands(customCmd.actionPipeline)
                val macroIntents = expandedSegments.map { seg ->
                    parseSingleSegment(seg, detectedLang)
                }
                return NluAnalysisResult(
                    rawUtterance = rawUtterance,
                    detectedLanguage = detectedLang,
                    intents = macroIntents,
                    matchedCustomCommandId = customCmd.id,
                    matchedCustomCommandTitle = customCmd.title
                )
            }
        }

        // 4. Split Multi-Action Utterances and Parse Each Segment
        val segments = TextNormalizer.splitMultiActionCommands(rawUtterance)
        val parsedIntents = if (segments.isEmpty()) {
            listOf(parseSingleSegment(rawUtterance, detectedLang))
        } else {
            segments.map { segment ->
                val segLang = TextNormalizer.detectLanguage(segment).let {
                    if (segment.any { c -> c.isLetter() }) it else detectedLang
                }
                parseSingleSegment(segment, segLang)
            }
        }

        return NluAnalysisResult(
            rawUtterance = rawUtterance,
            detectedLanguage = detectedLang,
            intents = parsedIntents
        )
    }

    private fun parseSingleSegment(rawSegment: String, language: AssistantLanguage): ParsedCommandIntent {
        val normalized = TextNormalizer.normalize(rawSegment)
        for (plugin in registeredPlugins) {
            val matched = plugin.matchIntent(rawSegment, normalized, language)
            if (matched != null) {
                return matched
            }
        }

        return ParsedCommandIntent(
            pluginId = "unrecognized",
            actionId = "UNKNOWN_COMMAND",
            category = CommandCategory.UNKNOWN,
            rawSegment = rawSegment,
            normalizedSegment = normalized,
            language = language,
            confidence = 0.0f
        )
    }

    private fun resolveClarificationFollowUp(
        pendingIntent: ParsedCommandIntent,
        followUpRaw: String,
        followUpNormalized: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        // First check if the follow-up is itself a complete valid command
        val directMatch = parseSingleSegment(followUpRaw, language)
        if (directMatch.actionId != "UNKNOWN_COMMAND" && !directMatch.requiresClarification) {
            return directMatch
        }

        return when (pendingIntent.actionId) {
            "OPEN_APP" -> {
                val cleanedApp = followUpNormalized
                    .removePrefix("تطبيق ")
                    .removePrefix("برنامج ")
                    .removePrefix("افتح ")
                    .removePrefix("open ")
                    .trim()
                if (cleanedApp.isNotBlank()) {
                    pendingIntent.copy(
                        parameters = mapOf("appQuery" to cleanedApp),
                        clarificationPromptAr = null,
                        clarificationPromptEn = null,
                        clarificationOptions = emptyList()
                    )
                } else null
            }

            "SET_ALARM" -> {
                val combined = if (pendingIntent.language == AssistantLanguage.AR) {
                    "اضبط منبه $followUpRaw"
                } else {
                    "set alarm $followUpRaw"
                }
                val reparsed = parseSingleSegment(combined, pendingIntent.language)
                if (!reparsed.requiresClarification && reparsed.actionId == "SET_ALARM") reparsed else null
            }

            "SET_TIMER" -> {
                val combined = if (pendingIntent.language == AssistantLanguage.AR) {
                    "اضبط مؤقت $followUpRaw"
                } else {
                    "set timer $followUpRaw"
                }
                val reparsed = parseSingleSegment(combined, pendingIntent.language)
                if (!reparsed.requiresClarification && reparsed.actionId == "SET_TIMER") reparsed else null
            }

            "CALL_NUMBER", "SEND_SMS" -> {
                val phone = TextNormalizer.extractPhoneNumber(followUpRaw)
                if (!phone.isNullOrBlank()) {
                    pendingIntent.copy(
                        parameters = pendingIntent.parameters + ("phone" to phone),
                        clarificationPromptAr = null,
                        clarificationPromptEn = null,
                        clarificationOptions = emptyList()
                    )
                } else null
            }

            else -> null
        }
    }

    private fun isBlockedShellOrCodeAttempt(normalized: String): Boolean {
        val forbiddenTokens = listOf(
            "rm -rf", "su -c", "sh -c", "bash -c", "chmod 777", "/system/bin",
            "runtime getruntime", "exec(", "eval(", "drop table", "adb shell"
        )
        return forbiddenTokens.any { normalized.contains(it) }
    }
}
