package com.example.sharafi.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.sharafi.data.AssistantSettingsEntity
import com.example.sharafi.data.CommandHistoryEntity
import com.example.sharafi.domain.executor.DeviceCapabilitiesSnapshot
import com.example.sharafi.domain.nlu.ActionExecutionResult
import com.example.sharafi.domain.nlu.AssistantLanguage
import com.example.sharafi.domain.nlu.ExecutionOutcomeStatus
import com.example.sharafi.service.SpeechListeningState
import com.example.sharafi.ui.ActiveExecutionConsoleState
import com.example.ui.theme.AmberAlert
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CoralContainer
import com.example.ui.theme.CoralDanger
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianDeep
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.TurquoiseContainer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CommandCenterScreen(
    isArabic: Boolean,
    settings: AssistantSettingsEntity,
    listeningState: SpeechListeningState,
    partialTranscript: String,
    rmsAmplitude: Float,
    engineStatusMessage: String,
    isSpeaking: Boolean,
    consoleState: ActiveExecutionConsoleState,
    capabilities: DeviceCapabilitiesSnapshot,
    recentHistory: List<CommandHistoryEntity>,
    onMicClick: () -> Unit,
    onExecuteCommand: (String) -> Unit,
    onToggleLanguage: () -> Unit,
    onToggleVoiceResponses: (Boolean) -> Unit,
    onReplayResponse: () -> Unit,
    onConfirmSensitiveAction: () -> Unit,
    onCancelSensitiveAction: () -> Unit,
    onDismissClarification: () -> Unit,
    onViewAllHistory: () -> Unit
) {
    var commandTextInput by rememberSaveable { mutableStateOf("") }

    val quickCommandsAr = listOf(
        "كم نسبة البطارية",
        "شغل الفلاش",
        "اطفئ الفلاش",
        "ارفع الصوت الى 80",
        "وضع الاهتزاز",
        "كم الساعة الان",
        "مساحة التخزين المتبقية",
        "اضبط مؤقت لمدة 10 دقائق",
        "اضبط منبه على الساعة 7 صباحا",
        "افتح اعدادات الواي فاي",
        "احسب 25 ضرب 12",
        "وضع النوم",
        "فحص شامل",
        "شغل الفلاش ثم كم نسبة البطارية"
    )

    val quickCommandsEn = listOf(
        "What is the battery level",
        "Turn on flashlight",
        "Turn off flashlight",
        "Set volume to 80",
        "Vibrate mode",
        "What time is it",
        "Available storage space",
        "Set timer for 10 minutes",
        "Set alarm for 7:30 AM",
        "Open Wi-Fi settings",
        "Calculate 25 times 12",
        "Sleep mode",
        "Full status report",
        "Turn on flashlight and then check battery level"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDeep)
            .testTag("command_center_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Futuristic Hero Header & Offline Privacy Status Bar
        item {
            HeroHeaderBanner(
                isArabic = isArabic,
                voiceEnabled = settings.voiceResponsesEnabled,
                capabilities = capabilities,
                onToggleLanguage = onToggleLanguage,
                onToggleVoice = { onToggleVoiceResponses(!settings.voiceResponsesEnabled) }
            )
        }

        // 2. Glowing Acoustic Microphone Core & Live Waveform Visualizer
        item {
            GlowingVoiceCoreCard(
                isArabic = isArabic,
                listeningState = listeningState,
                partialTranscript = partialTranscript,
                rmsAmplitude = rmsAmplitude,
                engineStatusMessage = engineStatusMessage,
                isSpeaking = isSpeaking,
                recognitionMode = settings.recognitionLanguageMode,
                onMicClick = onMicClick
            )
        }

        // 3. Sensitive Action Confirmation Guard (if active)
        if (consoleState.pendingSensitiveConfirmation != null) {
            item {
                SensitiveActionConfirmationCard(
                    isArabic = isArabic,
                    prompt = consoleState.combinedAssistantResponse,
                    rawCommand = consoleState.pendingSensitiveConfirmation.rawSegment,
                    onConfirm = onConfirmSensitiveAction,
                    onCancel = onCancelSensitiveAction
                )
            }
        }

        // 4. Ambiguous Command Clarification Prompt (if active)
        if (consoleState.pendingClarification != null) {
            item {
                ClarificationPromptCard(
                    isArabic = isArabic,
                    question = consoleState.combinedAssistantResponse,
                    options = consoleState.pendingClarification.clarificationOptions,
                    onSelectOption = { chosen -> onExecuteCommand(chosen) },
                    onDismiss = onDismissClarification
                )
            }
        }

        // 5. Recognized Speech, Execution Pipeline & Assistant Response Console
        item {
            ExecutionResponseConsoleCard(
                isArabic = isArabic,
                consoleState = consoleState,
                onReplayResponse = onReplayResponse
            )
        }

        // 6. Natural Voice Command Simulator / Manual Command Input Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = CyanGlow,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isArabic) "محاكي الأوامر الصوتية والإدخال المباشر" else "Direct Command Input & Voice Simulator",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (isArabic) "عربي + EN" else "AR + EN",
                            style = MaterialTheme.typography.labelSmall,
                            color = TurquoiseAccent
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = commandTextInput,
                            onValueChange = { commandTextInput = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("command_input_field"),
                            placeholder = {
                                Text(
                                    text = if (isArabic) {
                                        "اكتب أمراً طبيعياً (مثل: شغل الفلاش ثم كم نسبة البطارية)..."
                                    } else {
                                        "Enter natural command (e.g. Turn on flashlight then check battery)..."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (commandTextInput.isNotBlank()) {
                                        onExecuteCommand(commandTextInput)
                                        commandTextInput = ""
                                    }
                                }
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanGlow,
                                unfocusedBorderColor = BorderSubtle,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = CyanGlow,
                                focusedContainerColor = ObsidianSurface,
                                unfocusedContainerColor = ObsidianSurface
                            ),
                            shape = RoundedCornerShape(14.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (commandTextInput.isNotBlank()) {
                                    onExecuteCommand(commandTextInput)
                                    commandTextInput = ""
                                }
                            },
                            modifier = Modifier
                                .height(54.dp)
                                .testTag("execute_command_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanGlow,
                                contentColor = ObsidianDeep
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = if (isArabic) "تنفيذ الأمر" else "Execute Command"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isArabic) "اضغط لتجربة أوامر صوتية فورية (مفردة أو مركبة):" else "Tap to test instant offline voice commands (single or multi-step):",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val chips = if (isArabic) quickCommandsAr else quickCommandsEn
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        chips.forEachIndexed { index, cmd ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onExecuteCommand(cmd) }
                                    .testTag("quick_cmd_chip_$index"),
                                color = ObsidianElevated,
                                border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.35f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = CyanGlow,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = cmd,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 7. Recent Executed Commands Preview
        if (recentHistory.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = TurquoiseAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "آخر الأوامر المنفذة محلياً" else "Recent Local Executions",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (isArabic) "عرض السجل الكامل ←" else "View All →",
                        style = MaterialTheme.typography.labelLarge,
                        color = CyanGlow,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onViewAllHistory() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("view_all_history_link")
                    )
                }
            }

            items(recentHistory.take(3), key = { it.id }) { item ->
                RecentHistoryCompactRow(
                    item = item,
                    isArabic = isArabic,
                    onReExecute = { onExecuteCommand(item.rawUtterance) }
                )
            }
        }
    }
}

@Composable
private fun HeroHeaderBanner(
    isArabic: Boolean,
    voiceEnabled: Boolean,
    capabilities: DeviceCapabilitiesSnapshot,
    onToggleLanguage: () -> Unit,
    onToggleVoice: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.4f)),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_core_1794491000757),
                contentDescription = "SHARAFI AI Acoustic Core Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(132.dp),
                alpha = 0.35f
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(132.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianDeep.copy(alpha = 0.35f),
                                ObsidianSurface.copy(alpha = 0.92f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.img_launcher_icon_1794490998927),
                            contentDescription = "SHARAFI AI Emblem",
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.dp, CyanGlow, RoundedCornerShape(12.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SHARAFI AI",
                                style = MaterialTheme.typography.titleLarge,
                                color = CyanGlow,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isArabic) {
                                    "المساعد الصوتي الذكي • تحكم كامل بدون إنترنت"
                                } else {
                                    "Autonomous Offline Android Voice Controller"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = onToggleVoice,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(ObsidianElevated)
                                .testTag("toggle_tts_button")
                        ) {
                            Icon(
                                imageVector = if (voiceEnabled) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                                contentDescription = if (isArabic) "تبديل الرد الصوتي" else "Toggle Voice Synthesis",
                                tint = if (voiceEnabled) TurquoiseAccent else TextMuted
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .height(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onToggleLanguage() }
                                .testTag("language_toggle_button"),
                            color = CyanContainer,
                            border = BorderStroke(1.dp, CyanGlow)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Switch Language",
                                    tint = CyanGlow,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isArabic) "EN" else "عربي",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Live Telemetry & Offline Guarantee Strip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = TurquoiseContainer,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, TurquoiseAccent.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = TurquoiseAccent,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isArabic) "متصل محلياً 100% • صفر سحابة" else "100% OFFLINE • ZERO CLOUD",
                                style = MaterialTheme.typography.labelSmall,
                                color = TurquoiseAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        color = ObsidianElevated,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (isArabic) {
                                "البطارية ${capabilities.batteryPercent}% • الصوت ${capabilities.currentVolumePercent}%"
                            } else {
                                "BAT ${capabilities.batteryPercent}% • VOL ${capabilities.currentVolumePercent}%"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    if (capabilities.isTorchCurrentlyOn) {
                        Surface(
                            color = AmberContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FlashlightOn,
                                    contentDescription = null,
                                    tint = AmberAlert,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isArabic) "الكشاف يعمل" else "TORCH ON",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberAlert
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GlowingVoiceCoreCard(
    isArabic: Boolean,
    listeningState: SpeechListeningState,
    partialTranscript: String,
    rmsAmplitude: Float,
    engineStatusMessage: String,
    isSpeaking: Boolean,
    recognitionMode: String,
    onMicClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_core_pulse")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulsePhase"
    )
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowScale"
    )

    val isListening = listeningState == SpeechListeningState.LISTENING ||
        listeningState == SpeechListeningState.PROCESSING

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
        border = BorderStroke(
            width = if (isListening) 1.5.dp else 1.dp,
            color = if (isListening) CyanGlow else BorderSubtle
        ),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Mode Tag
            Surface(
                color = ObsidianCard,
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Text(
                    text = when {
                        isListening -> if (isArabic) "● يستمع الآن إلى صوتك محلياً..." else "● LISTENING ON-DEVICE..."
                        isSpeaking -> if (isArabic) "◉ شرافي يتحدث الآن..." else "◉ SHARAFI SPEAKING..."
                        else -> if (isArabic) {
                            "محرك الصوت المحلي جاهز (${if (recognitionMode == "AUTO") "تلقائي عربي/EN" else recognitionMode})"
                        } else {
                            "LOCAL ACOUSTIC ENGINE READY ($recognitionMode)"
                        }
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = when {
                        isListening -> CyanGlow
                        isSpeaking -> TurquoiseAccent
                        else -> TextSecondary
                    },
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Glowing Orb + Dynamic Acoustic Waveform Ring
            Box(
                modifier = Modifier
                    .size(168.dp)
                    .clickable { onMicClick() }
                    .testTag("glowing_microphone_button"),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val baseRadius = size.minDimension * 0.29f
                    val activeBoost = if (isListening) (rmsAmplitude * 24f + 10f) else if (isSpeaking) 8f else 0f

                    // Outer Sonar Rings
                    for (ring in 1..3) {
                        val ringRadius = baseRadius + ring * 16.dp.toPx() * glowScale + activeBoost
                        val alpha = (0.36f / ring) * if (isListening || isSpeaking) 1.2f else 0.65f
                        drawCircle(
                            color = if (ring % 2 == 0) TurquoiseAccent.copy(alpha = alpha) else CyanGlow.copy(alpha = alpha),
                            radius = ringRadius,
                            center = center,
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }

                    // Radial Acoustic Frequency Bars
                    val barCount = 28
                    for (i in 0 until barCount) {
                        val angle = (i.toFloat() / barCount) * 2f * PI.toFloat() + pulsePhase * 0.35f
                        val waveFactor = if (isListening) {
                            0.35f + 0.65f * kotlin.math.abs(sin(pulsePhase * 2f + i * 0.55f)) * (0.4f + rmsAmplitude)
                        } else if (isSpeaking) {
                            0.3f + 0.5f * kotlin.math.abs(cos(pulsePhase * 3f + i * 0.4f))
                        } else {
                            0.18f + 0.12f * sin(pulsePhase + i * 0.4f)
                        }

                        val innerR = baseRadius + 8.dp.toPx()
                        val outerR = innerR + (22.dp.toPx() * waveFactor)

                        val start = Offset(
                            x = center.x + innerR * cos(angle),
                            y = center.y + innerR * sin(angle)
                        )
                        val end = Offset(
                            x = center.x + outerR * cos(angle),
                            y = center.y + outerR * sin(angle)
                        )
                        drawLine(
                            color = if (i % 2 == 0) CyanGlow else TurquoiseAccent,
                            start = start,
                            end = end,
                            strokeWidth = 3.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Core Glowing Microphone Button
                Surface(
                    modifier = Modifier.size(88.dp),
                    shape = CircleShape,
                    color = if (isListening) CyanGlow else ObsidianElevated,
                    border = BorderStroke(2.5.dp, if (isListening) Color.White else CyanGlow),
                    shadowElevation = 12.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = if (isArabic) "زر الميكروفون الصوتي" else "Voice Microphone Button",
                            tint = if (isListening) ObsidianDeep else CyanGlow,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (partialTranscript.isNotBlank() && isListening) {
                    "\"$partialTranscript\""
                } else {
                    engineStatusMessage
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (isListening) CyanGlow else TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SensitiveActionConfirmationCard(
    isArabic: Boolean,
    prompt: String,
    rawCommand: String,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sensitive_confirmation_card"),
        colors = CardDefaults.cardColors(containerColor = AmberContainer),
        border = BorderStroke(1.5.dp, AmberAlert),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = AmberAlert
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isArabic) "تأكيد أمان لإجراء حساس" else "Sensitive Operation Security Guard",
                    style = MaterialTheme.typography.titleMedium,
                    color = AmberAlert,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = prompt,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )

            Text(
                text = if (isArabic) "الأمر المطلوب: $rawCommand" else "Requested Command: $rawCommand",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onConfirm,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("confirm_sensitive_action_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberAlert,
                        contentColor = ObsidianDeep
                    )
                ) {
                    Text(
                        text = if (isArabic) "تأكيد وتنفيذ" else "Confirm & Execute",
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("cancel_sensitive_action_btn"),
                    border = BorderStroke(1.dp, TextSecondary)
                ) {
                    Text(
                        text = if (isArabic) "إلغاء" else "Cancel",
                        color = TextPrimary
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ClarificationPromptCard(
    isArabic: Boolean,
    question: String,
    options: List<String>,
    onSelectOption: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("clarification_prompt_card"),
        colors = CardDefaults.cardColors(containerColor = CyanContainer),
        border = BorderStroke(1.5.dp, CyanGlow),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = null,
                        tint = CyanGlow
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isArabic) "سؤال توضيحي من شرافي" else "Clarification Needed",
                        style = MaterialTheme.typography.titleMedium,
                        color = CyanGlow,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (isArabic) "تجاهل" else "Dismiss",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    modifier = Modifier
                        .clickable { onDismiss() }
                        .padding(4.dp)
                )
            }

            Text(
                text = question,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )

            if (options.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    options.forEach { option ->
                        FilledTonalButton(
                            onClick = { onSelectOption(option) },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = ObsidianElevated,
                                contentColor = CyanGlow
                            )
                        ) {
                            Text(text = option, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExecutionResponseConsoleCard(
    isArabic: Boolean,
    consoleState: ActiveExecutionConsoleState,
    onReplayResponse: () -> Unit
) {
    val (statusColor, statusLabelAr, statusLabelEn, statusIcon) = when (consoleState.overallStatus) {
        ExecutionOutcomeStatus.VERIFIED_SUCCESS -> QuadStatus(
            EmeraldSuccess,
            "تم التنفيذ والتحقق بنجاح",
            "VERIFIED SUCCESS",
            Icons.Default.CheckCircle
        )
        ExecutionOutcomeStatus.PARTIAL_SUCCESS -> QuadStatus(
            TurquoiseAccent,
            "تنفيذ جزئي متعدد الخطوات",
            "PARTIAL MULTI-STEP",
            Icons.Default.CheckCircle
        )
        ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE -> QuadStatus(
            CyanGlow,
            "تم فتح البديل الآمن للنظام",
            "SYSTEM SAFE ALTERNATIVE",
            Icons.Default.Shield
        )
        ExecutionOutcomeStatus.AWAITING_CONFIRMATION -> QuadStatus(
            AmberAlert,
            "بانتظار تأكيد المستخدم",
            "AWAITING CONFIRMATION",
            Icons.Default.WarningAmber
        )
        ExecutionOutcomeStatus.NEEDS_CLARIFICATION -> QuadStatus(
            CyanGlow,
            "بحاجة إلى توضيح المعطيات",
            "CLARIFICATION REQUESTED",
            Icons.Default.HelpOutline
        )
        ExecutionOutcomeStatus.MISSING_PERMISSION -> QuadStatus(
            AmberAlert,
            "يتطلب صلاحية أندرويد",
            "PERMISSION REQUIRED",
            Icons.Default.WarningAmber
        )
        ExecutionOutcomeStatus.FAILED -> QuadStatus(
            CoralDanger,
            "تعذر التنفيذ / غير مدعوم",
            "EXECUTION FAILED",
            Icons.Default.ErrorOutline
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("execution_console_card"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.55f)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = statusIcon,
                        contentDescription = null,
                        tint = statusColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isArabic) statusLabelAr else statusLabelEn,
                        style = MaterialTheme.typography.labelLarge,
                        color = statusColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (consoleState.executionDurationMs > 0) {
                        Text(
                            text = "${consoleState.executionDurationMs} ms",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                    Surface(
                        color = ObsidianElevated,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = consoleState.detectedLanguage.code,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanGlow,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Recognized Speech Bubble
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = ObsidianSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isArabic) "العبارة المنطوقة / المدخلة:" else "Recognized Utterance:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = consoleState.lastSpokenOrTypedCommand,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.testTag("recognized_speech_text")
                    )
                    if (consoleState.matchedMacroTitle != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isArabic) {
                                "⚡ تم تفعيل الأمر المخصص: ${consoleState.matchedMacroTitle}"
                            } else {
                                "⚡ Triggered Custom Macro: ${consoleState.matchedMacroTitle}"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = TurquoiseAccent
                        )
                    }
                }
            }

            // Assistant Verified Response
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isArabic) "استجابة المساعد (SHARAFI AI):" else "SHARAFI AI Verified Response:",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyanGlow
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = consoleState.combinedAssistantResponse,
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary,
                        modifier = Modifier.testTag("assistant_response_text")
                    )
                }

                IconButton(
                    onClick = onReplayResponse,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("replay_tts_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = if (isArabic) "إعادة نطق الرد" else "Speak Response Again",
                        tint = CyanGlow
                    )
                }
            }

            // Multi-step execution breakdown if present
            AnimatedVisibility(visible = consoleState.stepResults.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    consoleState.stepResults.forEachIndexed { idx, step ->
                        StepExecutionBadgeRow(index = idx + 1, step = step, isArabic = isArabic)
                    }
                }
            }
        }
    }
}

@Composable
private fun StepExecutionBadgeRow(
    index: Int,
    step: ActionExecutionResult,
    isArabic: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ObsidianElevated.copy(alpha = 0.7f),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "#$index • ${if (isArabic) step.category.titleAr else step.category.titleEn} (${step.actionId})",
                style = MaterialTheme.typography.labelMedium,
                color = CyanGlow,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = step.technicalDetail,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RecentHistoryCompactRow(
    item: CommandHistoryEntity,
    isArabic: Boolean,
    onReExecute: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onReExecute() },
        color = ObsidianSurface,
        border = BorderStroke(1.dp, BorderSubtle),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.rawUtterance,
                    style = MaterialTheme.typography.titleSmall,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = item.assistantResponse,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = if (isArabic) "إعادة تنفيذ" else "Re-run command",
                tint = CyanGlow
            )
        }
    }
}

private data class QuadStatus(
    val color: Color,
    val labelAr: String,
    val labelEn: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)
