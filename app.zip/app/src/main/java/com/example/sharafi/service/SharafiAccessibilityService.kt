package com.example.sharafi.service

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Optional, user-authorized Accessibility Service for executing global navigation
 * commands offline (Back, Home, Recents, Notifications, Quick Settings, Lock Screen).
 * Never reads screen content (`canRetrieveWindowContent="false"` in config).
 */
class SharafiAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No screen scraping or window content inspection; privacy-first global action bridge only.
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
            _isConnected.value = false
        }
        super.onDestroy()
    }

    fun performSystemAction(actionCode: String): Boolean {
        val globalAction = when (actionCode) {
            "GLOBAL_BACK" -> GLOBAL_ACTION_BACK
            "GLOBAL_HOME" -> GLOBAL_ACTION_HOME
            "GLOBAL_RECENTS" -> GLOBAL_ACTION_RECENTS
            "GLOBAL_NOTIFICATIONS" -> GLOBAL_ACTION_NOTIFICATIONS
            "GLOBAL_QUICK_SETTINGS" -> GLOBAL_ACTION_QUICK_SETTINGS
            "GLOBAL_LOCK_SCREEN" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    GLOBAL_ACTION_LOCK_SCREEN
                } else {
                    return false
                }
            }
            else -> return false
        }
        return performGlobalAction(globalAction)
    }

    companion object {
        @Volatile
        var instance: SharafiAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()
    }
}
