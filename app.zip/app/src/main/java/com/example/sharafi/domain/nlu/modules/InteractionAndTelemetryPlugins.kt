package com.example.sharafi.domain.nlu.modules

import com.example.sharafi.domain.nlu.AssistantLanguage
import com.example.sharafi.domain.nlu.CommandCategory
import com.example.sharafi.domain.nlu.CommandModulePlugin
import com.example.sharafi.domain.nlu.ParsedCommandIntent
import com.example.sharafi.domain.nlu.TextNormalizer

class CameraMediaPlugin : CommandModulePlugin {
    override val pluginId: String = "camera_media"
    override val category: CommandCategory = CommandCategory.CAMERA_MEDIA
    override val supportedActionsSummaryAr: List<String> = listOf(
        "افتح الكاميرا / صور سلفي / تسجيل فيديو",
        "شغل الموسيقى / أوقف الأغنية / المقطع التالي / المقطع السابق"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Open camera / Take a selfie / Record video",
        "Play music / Pause track / Next song / Previous track"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        // Camera intents
        if (listOf("سلفي", "سيلفي", "الكاميرا الاماميه", "كاميرا اماميه", "selfie", "front camera").any { normalizedSegment.contains(it) }) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "CAMERA_SELFIE",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("تسجيل فيديو", "صور فيديو", "كاميرا فيديو", "فيديو بالكاميرا", "record video", "video camera", "shoot video")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "CAMERA_VIDEO",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("افتح الكاميرا", "شغل الكاميرا", "التقط صوره", "تصوير صوره", "صور صوره", "open camera", "take a photo", "take picture", "launch camera")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "CAMERA_PHOTO",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        // Media Playback Intents
        if (listOf("الاغنيه التاليه", "المقطع التالي", "التالي", "تخطي الاغنيه", "next track", "next song", "skip song", "skip track")
                .any { normalizedSegment == it || normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "MEDIA_NEXT",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("الاغنيه السابقه", "المقطع السابق", "السابق", "previous track", "previous song", "prev track")
                .any { normalizedSegment == it || normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "MEDIA_PREVIOUS",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("اوقف الموسيقي", "اوقف الاغنيه", "وقف الاغنيه", "ايقاف مؤقت", "pause music", "stop music", "pause track", "pause playback")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "MEDIA_PAUSE",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("شغل الموسيقي", "شغل الاغاني", "استمر في التشغيل", "استئناف الموسيقي", "play music", "resume music", "resume playback")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "MEDIA_PLAY",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        return null
    }
}

class CommunicationPlugin : CommandModulePlugin {
    override val pluginId: String = "communication_phone"
    override val category: CommandCategory = CommandCategory.COMMUNICATION
    override val supportedActionsSummaryAr: List<String> = listOf(
        "اتصل بالرقم [رقم الهاتف] (مع تأكيد أمان مسبق)",
        "أرسل رسالة نصية إلى [رقم الهاتف] (مع تأكيد أمان مسبق)",
        "افتح لوحة الاتصال"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Call / Dial [Phone Number] (with safety confirmation)",
        "Send SMS to [Phone Number] [Message] (with safety confirmation)",
        "Open phone dialer"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        if (listOf("لوحه الاتصال", "افتح الهاتف", "افتح الاتصال", "open dialer", "phone dialer")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "OPEN_DIALER",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        val isSms = listOf("ارسل رساله", "ابعت رساله", "رساله نصيه", "اس ام اس", "send sms", "send message", "text message")
            .any { normalizedSegment.contains(it) }
        if (isSms) {
            val phone = TextNormalizer.extractPhoneNumber(rawSegment)
            if (phone.isNullOrBlank()) {
                return ParsedCommandIntent(
                    pluginId = pluginId,
                    actionId = "SEND_SMS",
                    category = category,
                    isSensitive = true,
                    rawSegment = rawSegment,
                    normalizedSegment = normalizedSegment,
                    language = language,
                    clarificationPromptAr = "ما هو رقم الهاتف الذي تريد إرسال الرسالة إليه؟",
                    clarificationPromptEn = "What phone number would you like to send the message to?",
                    clarificationOptions = listOf("ارسل رسالة الى 0501234567 مرحبا", "افتح لوحة الاتصال")
                )
            }
            val bodyAfterNumber = rawSegment.substringAfter(phone, "").trim()
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "SEND_SMS",
                category = category,
                parameters = mapOf(
                    "phone" to phone,
                    "body" to bodyAfterNumber.ifBlank { if (language == AssistantLanguage.AR) "مرحباً" else "Hello" }
                ),
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language,
                isSensitive = true
            )
        }

        val isCall = listOf("اتصل ب", "اتصل علي", "اتصل بالرقم", "كلم رقم", "اتصل", "call ", "dial ")
            .any { normalizedSegment.startsWith(it) || normalizedSegment.contains(it) }
        if (isCall) {
            val phone = TextNormalizer.extractPhoneNumber(rawSegment)
            if (phone.isNullOrBlank()) {
                return ParsedCommandIntent(
                    pluginId = pluginId,
                    actionId = "CALL_NUMBER",
                    category = category,
                    isSensitive = true,
                    rawSegment = rawSegment,
                    normalizedSegment = normalizedSegment,
                    language = language,
                    clarificationPromptAr = "يرجى نطق رقم الهاتف المراد الاتصال به، أو اختيار فتح لوحة الاتصال.",
                    clarificationPromptEn = "Please specify the phone number to call, or choose to open the dialer.",
                    clarificationOptions = listOf("افتح لوحة الاتصال", "اتصل بالرقم 0501234567")
                )
            }
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "CALL_NUMBER",
                category = category,
                parameters = mapOf("phone" to phone),
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language,
                isSensitive = true
            )
        }

        return null
    }
}

class DeviceTelemetryPlugin : CommandModulePlugin {
    override val pluginId: String = "device_telemetry"
    override val category: CommandCategory = CommandCategory.DEVICE_TELEMETRY
    override val supportedActionsSummaryAr: List<String> = listOf(
        "كم نسبة البطارية / حالة الشحن",
        "كم الساعة الآن / ما هو التاريخ اليوم",
        "مساحة التخزين المتبقية / حالة الذاكرة العشوائية RAM",
        "مواصفات الجهاز / حالة الشبكة والاتصال"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "What is the battery level / Charging status",
        "What time is it / What is today's date",
        "Available storage space / RAM memory status",
        "Device specifications / Network & Bluetooth status"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        if (listOf(
                "نسبه البطاريه", "كم البطاريه", "كم باقي شحن", "حاله البطاريه", "شحن البطاريه", "البطاريه كم",
                "battery level", "battery status", "battery percentage", "how much battery", "is phone charging"
            ).any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "QUERY_BATTERY",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf(
                "كم الساعه", "الساعه كم", "كم الوقت", "الوقت الان", "ما هو التاريخ", "تاريخ اليوم", "اي يوم اليوم", "اليوم ايش",
                "what time", "current time", "what is the time", "today's date", "what day is it", "current date"
            ).any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "QUERY_TIME_DATE",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf(
                "مساحه التخزين", "الذاكره المتبقيه", "المساحه الفارغه", "الذاكره العشوائيه", "حجم الرام", "حاله الذاكره",
                "available storage", "free storage", "memory status", "ram status", "disk space"
            ).any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "QUERY_STORAGE_RAM",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf(
                "حاله الشبكه", "حاله الاتصال", "هل الواي فاي", "هل البلوتوث", "فحص الاتصال",
                "network status", "connectivity status", "is wifi connected"
            ).any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "QUERY_CONNECTIVITY",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf(
                "مواصفات الجهاز", "معلومات الهاتف", "معلومات الجهاز", "نوع الهاتف", "اصدار الاندرويد", "من انت", "عرفني بنفسك",
                "device info", "phone specs", "android version", "device specifications", "who are you"
            ).any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "QUERY_DEVICE_SPECS",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        return null
    }
}

class AccessibilityNavPlugin : CommandModulePlugin {
    override val pluginId: String = "accessibility_nav"
    override val category: CommandCategory = CommandCategory.ACCESSIBILITY_NAV
    override val supportedActionsSummaryAr: List<String> = listOf(
        "ارجع للخلف / الشاشة الرئيسية / التطبيقات الأخيرة",
        "افتح الإشعارات / لوحة التحكم السريعة / اقفل الشاشة"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Go back / Go to home screen / Recent apps",
        "Open notifications / Quick settings panel / Lock screen"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        val navAction = when {
            listOf("ارجع للخلف", "خطوه للوراء", "الرجوع للخلف", "go back", "navigate back").any { normalizedSegment.contains(it) } ||
                normalizedSegment in listOf("رجوع", "ارجع", "back") -> "GLOBAL_BACK"

            listOf("الشاشه الرئيسيه", "اذهب للرئيسيه", "الصفحه الرئيسيه", "go home", "home screen").any { normalizedSegment.contains(it) } -> "GLOBAL_HOME"

            listOf("التطبيقات الاخيره", "التطبيقات المفتوحه", "البرامج الاخيره", "recent apps", "recents screen", "overview").any { normalizedSegment.contains(it) } -> "GLOBAL_RECENTS"

            listOf("افتح الاشعارات", "اعرض الاشعارات", "شريط الاشعارات", "الاشعارات", "open notifications", "show notifications", "notification shade")
                .any { normalizedSegment == it || normalizedSegment.contains(it) } -> "GLOBAL_NOTIFICATIONS"

            listOf("لوحه التحكم السريعه", "الاعدادات السريعه", "quick settings").any { normalizedSegment.contains(it) } -> "GLOBAL_QUICK_SETTINGS"

            listOf("اقفل الشاشه", "قفل الشاشه", "قفل الهاتف", "اغلق الشاشه", "lock screen", "lock phone", "lock device")
                .any { normalizedSegment.contains(it) } -> "GLOBAL_LOCK_SCREEN"

            else -> null
        } ?: return null

        return ParsedCommandIntent(
            pluginId = pluginId,
            actionId = navAction,
            category = category,
            rawSegment = rawSegment,
            normalizedSegment = normalizedSegment,
            language = language
        )
    }
}

class UtilityCalculatorPlugin : CommandModulePlugin {
    override val pluginId: String = "utility_calculator"
    override val category: CommandCategory = CommandCategory.UTILITY_CALC
    override val supportedActionsSummaryAr: List<String> = listOf(
        "احسب [رقم] جمع / طرح / ضرب / قسمة [رقم]"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Calculate [number] plus / minus / times / divided by [number]"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        val mathPrep = normalizedSegment
            .replace("ضرب", "*")
            .replace("في", "*")
            .replace("مضروب في", "*")
            .replace("times", "*")
            .replace("multiplied by", "*")
            .replace("قسمه", "/")
            .replace("تقسيم", "/")
            .replace("علي", "/")
            .replace("divided by", "/")
            .replace("زائد", "+")
            .replace("جمع", "+")
            .replace("plus", "+")
            .replace("ناقص", "-")
            .replace("طرح", "-")
            .replace("minus", "-")

        val match = Regex("(\\d+(?:\\.\\d+)?)\\s*([+\\-*/x×÷])\\s*(\\d+(?:\\.\\d+)?)").find(mathPrep)
            ?: return null

        val lhs = match.groupValues[1]
        val op = match.groupValues[2]
        val rhs = match.groupValues[3]

        return ParsedCommandIntent(
            pluginId = pluginId,
            actionId = "CALCULATE_EXPRESSION",
            category = category,
            parameters = mapOf("lhs" to lhs, "op" to op, "rhs" to rhs),
            rawSegment = rawSegment,
            normalizedSegment = normalizedSegment,
            language = language
        )
    }
}
