package com.example.sharafi.service

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.sharafi.domain.nlu.AssistantLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class OfflineTtsEngine(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _ttsDiagnostic = MutableStateFlow("Initializing local TextToSpeech...")
    val ttsDiagnostic: StateFlow<String> = _ttsDiagnostic.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            _ttsDiagnostic.value = "Local TTS unavailable: ${e.message}"
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            _isReady.value = true
            _ttsDiagnostic.value = "Offline TTS Engine Active (AR / EN)"
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
        } else {
            _isReady.value = false
            _ttsDiagnostic.value = "TTS initialization returned status $status"
        }
    }

    fun speakOffline(
        text: String,
        language: AssistantLanguage,
        enabled: Boolean,
        rate: Float = 1.0f,
        pitch: Float = 1.0f
    ) {
        if (!enabled || text.isBlank() || !_isReady.value) return
        val engine = tts ?: return

        try {
            val targetLocale = if (language == AssistantLanguage.AR) Locale("ar") else Locale.US
            val availability = engine.isLanguageAvailable(targetLocale)
            if (availability >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = targetLocale
                // Prefer strictly offline voice if available in voice list
                val offlineVoice = engine.voices?.firstOrNull { voice ->
                    voice.locale.language == targetLocale.language && !voice.isNetworkConnectionRequired
                }
                if (offlineVoice != null) {
                    engine.voice = offlineVoice
                }
            }

            engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
            engine.setPitch(pitch.coerceIn(0.5f, 2.0f))

            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, UUID.randomUUID().toString())
            }
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, UUID.randomUUID().toString())
        } catch (_: Exception) {
            _isSpeaking.value = false
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        _isSpeaking.value = false
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (_: Exception) {
        }
    }
}
