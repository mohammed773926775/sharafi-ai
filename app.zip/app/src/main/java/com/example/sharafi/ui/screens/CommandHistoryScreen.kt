package com.example.sharafi.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.sharafi.data.CommandHistoryEntity
import com.example.ui.theme.AmberAlert
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CoralDanger
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianDeep
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CommandHistoryScreen(
    isArabic: Boolean,
    historyItems: List<CommandHistoryEntity>,
    onReExecuteCommand: (String) -> Unit,
    onToggleFavorite: (CommandHistoryEntity) -> Unit,
    onDeleteItem: (Long) -> Unit,
    onClearAll: () -> Unit,
    onBackToCenter: () -> Unit
) {
    BackHandler { onBackToCenter() }

    var searchQuery by rememberSaveable { mutableStateOf("") }
    var onlyFavorites by rememberSaveable { mutableStateOf(false) }

    val filteredItems = historyItems.filter { item ->
        val matchesFavorite = !onlyFavorites || item.isFavorite
        val matchesSearch = searchQuery.isBlank() ||
            item.rawUtterance.contains(searchQuery, ignoreCase = true) ||
            item.assistantResponse.contains(searchQuery, ignoreCase = true) ||
            item.intentSummary.contains(searchQuery, ignoreCase = true)
        matchesFavorite && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDeep)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("history_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isArabic) "سجل الأوامر الصوتية المحلي" else "Local Voice Command History",
                    style = MaterialTheme.typography.headlineMedium,
                    color = CyanGlow,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isArabic) {
                        "إجمالي الأوامر المسجلة على الجهاز: ${historyItems.size}"
                    } else {
                        "Total commands stored locally on-device: ${historyItems.size}"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            if (historyItems.isNotEmpty()) {
                OutlinedButton(
                    onClick = onClearAll,
                    border = BorderStroke(1.dp, CoralDanger.copy(alpha = 0.6f)),
                    modifier = Modifier.testTag("clear_all_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = null,
                        tint = CoralDanger,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isArabic) "مسح الكل" else "Clear All",
                        color = CoralDanger,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search & Filter Row
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("history_search_field"),
            placeholder = {
                Text(
                    text = if (isArabic) "ابحث في الأوامر المنفذة أو استجابات المساعد..." else "Search spoken commands or assistant responses...",
                    color = TextMuted
                )
            },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = CyanGlow)
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyanGlow,
                unfocusedBorderColor = BorderSubtle,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedContainerColor = ObsidianSurface,
                unfocusedContainerColor = ObsidianSurface
            ),
            shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !onlyFavorites,
                onClick = { onlyFavorites = false },
                label = { Text(if (isArabic) "جميع الأوامر (${historyItems.size})" else "All (${historyItems.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyanContainer,
                    selectedLabelColor = CyanGlow
                )
            )
            FilterChip(
                selected = onlyFavorites,
                onClick = { onlyFavorites = !onlyFavorites },
                label = { Text(if (isArabic) "المفضلة ★" else "Favorites ★") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyanContainer,
                    selectedLabelColor = AmberAlert
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (filteredItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = if (isArabic) "لا توجد أوامر مطابقة في السجل المحلي بعد." else "No matching commands in local history yet.",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = if (isArabic) {
                            "يتم حفظ كل أمر صوتي محلياً في قاعدة بيانات Room المشفرة داخل جهازك فقط."
                        } else {
                            "Every voice command is logged strictly offline inside your on-device Room database."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredItems, key = { it.id }) { entry ->
                    HistoryDetailCard(
                        entry = entry,
                        isArabic = isArabic,
                        onReExecute = {
                            onReExecuteCommand(entry.rawUtterance)
                            onBackToCenter()
                        },
                        onToggleFavorite = { onToggleFavorite(entry) },
                        onDelete = { onDeleteItem(entry.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryDetailCard(
    entry: CommandHistoryEntity,
    isArabic: Boolean,
    onReExecute: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    val timeFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(entry.timestamp))
    val statusBadgeColor = when (entry.executionStatus) {
        "VERIFIED_SUCCESS" -> EmeraldSuccess
        "RESTRICTED_ALTERNATIVE", "PARTIAL_SUCCESS" -> CyanGlow
        "AWAITING_CONFIRMATION", "NEEDS_CLARIFICATION" -> AmberAlert
        else -> CoralDanger
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(1.dp, BorderSubtle),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = ObsidianElevated,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = entry.languageCode,
                            style = MaterialTheme.typography.labelSmall,
                            color = CyanGlow,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Surface(
                        color = ObsidianElevated,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = entry.intentSummary,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusBadgeColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = "${entry.executionDurationMs}ms",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }

                Text(
                    text = timeFormatted,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }

            Text(
                text = entry.rawUtterance,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = entry.assistantResponse,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (entry.isFavorite) Icons.Default.Star else Icons.Outlined.StarOutline,
                            contentDescription = if (isArabic) "مفضلة" else "Favorite",
                            tint = if (entry.isFavorite) AmberAlert else TextMuted
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = if (isArabic) "حذف" else "Delete",
                            tint = CoralDanger.copy(alpha = 0.8f)
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .clickable { onReExecute() }
                        .testTag("rerun_history_${entry.id}"),
                    color = CyanContainer,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, CyanGlow)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = CyanGlow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isArabic) "إعادة التنفيذ الآن" else "Execute Again",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}
