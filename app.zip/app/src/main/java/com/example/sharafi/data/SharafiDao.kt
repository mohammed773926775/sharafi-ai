package com.example.sharafi.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SharafiDao {

    // Command History
    @Query("SELECT * FROM command_history ORDER BY timestamp DESC")
    fun observeHistory(): Flow<List<CommandHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(entry: CommandHistoryEntity): Long

    @Query("UPDATE command_history SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setHistoryFavorite(id: Long, isFavorite: Boolean)

    @Query("DELETE FROM command_history WHERE id = :id")
    suspend fun deleteHistoryItem(id: Long)

    @Query("DELETE FROM command_history")
    suspend fun clearAllHistory()

    // Custom Commands
    @Query("SELECT * FROM custom_commands ORDER BY usageCount DESC, createdAt DESC")
    fun observeCustomCommands(): Flow<List<CustomCommandEntity>>

    @Query("SELECT * FROM custom_commands WHERE isEnabled = 1")
    suspend fun getEnabledCustomCommands(): List<CustomCommandEntity>

    @Query("SELECT COUNT(*) FROM custom_commands")
    suspend fun getCustomCommandCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomCommand(command: CustomCommandEntity): Long

    @Update
    suspend fun updateCustomCommand(command: CustomCommandEntity)

    @Query("UPDATE custom_commands SET isEnabled = :enabled WHERE id = :id")
    suspend fun setCustomCommandEnabled(id: Long, enabled: Boolean)

    @Query("UPDATE custom_commands SET usageCount = usageCount + 1 WHERE id = :id")
    suspend fun incrementCustomCommandUsage(id: Long)

    @Query("DELETE FROM custom_commands WHERE id = :id")
    suspend fun deleteCustomCommand(id: Long)

    // Assistant Settings
    @Query("SELECT * FROM assistant_settings WHERE id = 1")
    fun observeSettings(): Flow<AssistantSettingsEntity?>

    @Query("SELECT * FROM assistant_settings WHERE id = 1")
    suspend fun getSettingsOnce(): AssistantSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: AssistantSettingsEntity)
}
