package com.example.sharafi.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CommandHistoryEntity::class,
        CustomCommandEntity::class,
        AssistantSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SharafiDatabase : RoomDatabase() {
    abstract fun sharafiDao(): SharafiDao

    companion object {
        @Volatile
        private var INSTANCE: SharafiDatabase? = null

        fun getInstance(context: Context): SharafiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SharafiDatabase::class.java,
                    "sharafi_offline_assistant.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
