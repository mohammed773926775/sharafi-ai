package com.example.sharafi.domain.nlu

object TextNormalizer {

    private val arabicDiacriticsRegex = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val punctuationRegex = Regex("[.,،؛?!؟\"'«»()\\[\\]\\-_/+*=]")
    private val multiSpaceRegex = Regex("\\s+")

    private val arabicNumberWords = listOf(
        "مائه" to "100",
        "مئه" to "100",
        "ميه" to "100",
        "تسعين" to "90",
        "تسعون" to "90",
        "ثمانين" to "80",
        "ثمانون" to "80",
        "سبعين" to "70",
        "سبعون" to "70",
        "ستين" to "60",
        "ستون" to "60",
        "خمسين" to "50",
        "خمسون" to "50",
        "اربعين" to "40",
        "اربعون" to "40",
        "ثلاثين" to "30",
        "ثلاثون" to "30",
        "خمسه وعشرين" to "25",
        "عشرين" to "20",
        "عشرون" to "20",
        "خمسه عشر" to "15",
        "خمسطعش" to "15",
        "اربعه عشر" to "14",
        "ثلاثه عشر" to "13",
        "اثنا عشر" to "12",
        "اتناشر" to "12",
        "احد عشر" to "11",
        "حداشر" to "11",
        "عشره" to "10",
        "عشر" to "10",
        "تسعه" to "9",
        "تسع" to "9",
        "ثمانيه" to "8",
        "ثمان" to "8",
        "سبعه" to "7",
        "سبع" to "7",
        "سته" to "6",
        "ست" to "6",
        "خمسه" to "5",
        "خمس" to "5",
        "اربعه" to "4",
        "اربع" to "4",
        "ثلاثه" to "3",
        "ثلاث" to "3",
        "تلاته" to "3",
        "اثنين" to "2",
        "اثنان" to "2",
        "اتنين" to "2",
        "واحد" to "1",
        "واحده" to "1",
        "صفر" to "0"
    )

    private val englishNumberWords = listOf(
        "one hundred" to "100",
        "hundred" to "100",
        "ninety" to "90",
        "eighty" to "80",
        "seventy" to "70",
        "sixty" to "60",
        "fifty" to "50",
        "forty" to "40",
        "thirty" to "30",
        "twenty five" to "25",
        "twenty-five" to "25",
        "twenty" to "20",
        "fifteen" to "15",
        "fourteen" to "14",
        "thirteen" to "13",
        "twelve" to "12",
        "eleven" to "11",
        "ten" to "10",
        "nine" to "9",
        "eight" to "8",
        "seven" to "7",
        "six" to "6",
        "five" to "5",
        "four" to "4",
        "three" to "3",
        "two" to "2",
        "one" to "1",
        "zero" to "0"
    )

    fun detectLanguage(text: String): AssistantLanguage {
        val hasArabicChars = text.any { ch -> ch.code in 0x0600..0x06FF || ch.code in 0x0750..0x077F }
        return if (hasArabicChars) AssistantLanguage.AR else AssistantLanguage.EN
    }

    fun normalize(input: String, replaceNumberWords: Boolean = true): String {
        if (input.isBlank()) return ""

        val sb = StringBuilder(input.length)
        for (ch in input.lowercase()) {
            when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'ى' -> sb.append('ي')
                'ؤ' -> sb.append('و')
                'ئ' -> sb.append('ي')
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> sb.append(ch)
            }
        }

        var cleaned = sb.toString()
            .replace(arabicDiacriticsRegex, "")
            // Keep math symbols if present, strip conversational punctuation
            .replace(Regex("[.,،؛?!؟\"'«»]"), " ")
            .replace(multiSpaceRegex, " ")
            .trim()

        // Strip polite wake/filler prefixes so natural sentences match cleanly
        val politePrefixes = listOf(
            "يا شرافي ", "شرافي ", "ايها المساعد ", "لو سمحت ", "من فضلك ", "ممكن ", "اريد ان ", "اريد ", "ابغى ", "عايز ",
            "hey sharafi ", "ok sharafi ", "sharafi ", "please ", "can you ", "could you ", "i want to ", "would you "
        )
        for (prefix in politePrefixes) {
            if (cleaned.startsWith(prefix)) {
                cleaned = cleaned.removePrefix(prefix).trim()
            }
        }

        if (replaceNumberWords) {
            for ((word, digit) in arabicNumberWords) {
                cleaned = cleaned.replace(Regex("(?<=^|\\s)$word(?=\\s|$)"), digit)
            }
            for ((word, digit) in englishNumberWords) {
                cleaned = cleaned.replace(Regex("(?<=^|\\s)$word(?=\\s|$)"), digit)
            }
        }

        return cleaned.replace(multiSpaceRegex, " ").trim()
    }

    /**
     * Splits compound spoken requests into sequential atomic command segments.
     * Supports Arabic ("ثم", "وبعدين", "وبعد ذلك", "كمان", "و افتح", "و شغل"...)
     * and English ("and then", "then", "after that", "also", ";", "and open", "and turn"...).
     */
    fun splitMultiActionCommands(rawInput: String): List<String> {
        val normalizedForSplit = rawInput.trim()
        if (normalizedForSplit.isEmpty()) return emptyList()

        val splitPattern = Regex(
            pattern = "(?:\\s*;|\\s+ثم\\s+|\\s+وبعدين\\s+|\\s+وبعد ذلك\\s+|\\s+بعدين\\s+|\\s+كمان\\s+|\\s+وايضا\\s+|\\s+وأيضا\\s+" +
                "|\\s+و(?=افتح|شغل|اطفئ|اطفي|طفئ|طفي|ارفع|علي|خفض|وطي|اكتم|اضبط|اتصل|ارسل|احسب|كم\\s)" +
                "|\\s+and then\\s+|\\s+after that\\s+|\\s+then\\s+|\\s+also\\s+" +
                "|\\s+and\\s+(?=open|launch|turn|switch|set|increase|decrease|mute|unmute|call|dial|send|what|check|go\\s|lock\\s))",
            option = RegexOption.IGNORE_CASE
        )

        return normalizedForSplit
            .split(splitPattern)
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }

    fun extractFirstNumber(text: String): Int? {
        val match = Regex("(\\d+)").find(text)
        return match?.groupValues?.get(1)?.toIntOrNull()
    }

    fun extractPhoneNumber(text: String): String? {
        // Convert Eastern Arabic digits first
        val normalizedDigits = normalize(text, replaceNumberWords = false)
        val match = Regex("(\\+?\\d[\\d\\s\\-]{2,16}\\d)").find(normalizedDigits)
        return match?.value?.replace(Regex("[\\s\\-]"), "")
    }
}
