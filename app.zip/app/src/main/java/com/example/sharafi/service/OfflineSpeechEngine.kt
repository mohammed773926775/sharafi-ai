package com.example.sharafi.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.example.sharafi.domain.nlu.AssistantLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SpeechListeningState {
    IDLE,
    LISTENING,
    PROCESSING,
    ERROR
}

/**
 * Pluggable interface allowing independent local acoustic engines (e.g., Vosk / sherpa-onnx)
 * to be registered alongside Android's On-Device SpeechRecognizer without modifying the NLU layer.
 */
interface LocalAcousticEngineAdapter {
    val engineName: String
    val isReadyOffline: Boolean
    fun startListening(localeTag: String, onPartial: (String) -> Unit, onFinal: (String) -> Unit, onError: (String) -> Unit)
    fun stopListening()
}

class OfflineSpeechEngine(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var customAdapter: LocalAcousticEngineAdapter? = null

    private val _listeningState = MutableStateFlow(SpeechListeningState.IDLE)
    val listeningState: StateFlow<SpeechListeningState> = _listeningState.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _rmsAmplitude = MutableStateFlow(0f)
    val rmsAmplitude: StateFlow<Float> = _rmsAmplitude.asStateFlow()

    private val _engineStatusMessage = MutableStateFlow("On-Device Offline Speech Engine Ready")
    val engineStatusMessage: StateFlow<String> = _engineStatusMessage.asStateFlow()

    val isSystemSttAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    val isStrictOnDeviceSupported: Boolean
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        } else {
            SpeechRecognizer.isRecognitionAvailable(context)
        }

    fun registerExternalLocalAdapter(adapter: LocalAcousticEngineAdapter) {
        this.customAdapter = adapter
    }

    fun startOfflineListening(
        languageMode: String, // "AUTO", "AR", "EN"
        uiLanguage: AssistantLanguage,
        strictOffline: Boolean = true
    ) {
        mainHandler.post {
            val activeAdapter = customAdapter
            val targetLocale = when (languageMode) {
                "AR" -> "ar-SA"
                "EN" -> "en-US"
                else -> uiLanguage.localeTag
            }

            if (activeAdapter != null && activeAdapter.isReadyOffline) {
                _listeningState.value = SpeechListeningState.LISTENING
                _partialTranscript.value = ""
                activeAdapter.startListening(
                    localeTag = targetLocale,
                    onPartial = { _partialTranscript.value = it },
                    onFinal = { result ->
                        _listeningState.value = SpeechListeningState.IDLE
                        _rmsAmplitude.value = 0f
                        if (result.isNotBlank()) onFinalTranscript(result)
                    },
                    onError = { err ->
                        _listeningState.value = SpeechListeningState.ERROR
                        _engineStatusMessage.value = err
                    }
                )
                return@post
            }

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                _listeningState.value = SpeechListeningState.ERROR
                _engineStatusMessage.value = if (uiLanguage == AssistantLanguage.AR) {
                    "محرك التعرف الصوتي المحلي غير متوفر في صورة النظام هذه. يمكنك استخدام محاكي الأوامر الصوتية الفوري أدناه أو تثبيت حزمة الصوت دون اتصال."
                } else {
                    "System SpeechRecognizer service is not installed on this device image. Use the Instant Voice Command Deck below or install an offline speech pack."
                }
                return@post
            }

            try {
                speechRecognizer?.destroy()
                speechRecognizer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
                ) {
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                } else {
                    SpeechRecognizer.createSpeechRecognizer(context)
                }

                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _listeningState.value = SpeechListeningState.LISTENING
                        _engineStatusMessage.value = if (uiLanguage == AssistantLanguage.AR) {
                            "جاري الاستماع محلياً (${if (targetLocale.startsWith("ar")) "العربية" else "English"})..."
                        } else {
                            "Listening locally ($targetLocale)..."
                        }
                    }

                    override fun onBeginningOfSpeech() {
                        _listeningState.value = SpeechListeningState.LISTENING
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.05f, 1.0f)
                        _rmsAmplitude.value = normalized
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _listeningState.value = SpeechListeningState.PROCESSING
                        _rmsAmplitude.value = 0.1f
                    }

                    override fun onError(error: Int) {
                        _listeningState.value = SpeechListeningState.ERROR
                        _rmsAmplitude.value = 0f
                        _engineStatusMessage.value = mapSpeechError(error, uiLanguage)
                    }

                    override fun onResults(results: Bundle?) {
                        _listeningState.value = SpeechListeningState.IDLE
                        _rmsAmplitude.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val best = matches?.firstOrNull()?.trim().orEmpty()
                        if (best.isNotBlank()) {
                            _partialTranscript.value = best
                            onFinalTranscript(best)
                        } else {
                            _engineStatusMessage.value = if (uiLanguage == AssistantLanguage.AR) {
                                "لم يتم التقاط كلام واضح. حاول مرة أخرى."
                            } else {
                                "No clear speech detected. Please try again."
                            }
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            _partialTranscript.value = partial
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, targetLocale)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, targetLocale)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    // Strictly enforce offline processing
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, strictOffline)
                }

                _partialTranscript.value = ""
                _listeningState.value = SpeechListeningState.LISTENING
                speechRecognizer?.startListening(recognizerIntent)
            } catch (e: Exception) {
                _listeningState.value = SpeechListeningState.ERROR
                _rmsAmplitude.value = 0f
                _engineStatusMessage.value = if (uiLanguage == AssistantLanguage.AR) {
                    "تعذر بدء الميكروفون المحلي: ${e.localizedMessage ?: "خطأ في الخدمة"}"
                } else {
                    "Could not start local microphone: ${e.localizedMessage ?: "Service error"}"
                }
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                customAdapter?.stopListening()
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            _listeningState.value = SpeechListeningState.IDLE
            _rmsAmplitude.value = 0f
        }
    }

    fun destroy() {
        mainHandler.post {
            try {
                customAdapter?.stopListening()
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (_: Exception) {
            }
        }
    }

    private fun mapSpeechError(errorCode: Int, lang: AssistantLanguage): String {
        val isAr = lang == AssistantLanguage.AR
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> if (isAr) "خطأ في تسجيل الصوت من الميكروفون." else "Audio recording error from microphone."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> if (isAr) "يرجى منح صلاحية الميكروفون (RECORD_AUDIO) للاستماع الصوتي." else "Microphone permission (RECORD_AUDIO) is required."
            SpeechRecognizer.ERROR_NO_MATCH -> if (isAr) "لم يتم التعرف على العبارة المنطوقة محلياً. جرب مرة أخرى أو استخدم لوحة الأوامر الفورية." else "No local speech match found. Try speaking clearly or use the Instant Command Deck."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> if (isAr) "انتهت مهلة الاستماع دون التقاط صوت." else "Speech timeout: no audio input detected."
            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> if (isAr) "حزمة اللغة الصوتية دون اتصال غير مثبتة على هذا الجهاز. قم بتنزيل حزمة العربية/الإنجليزية للتعرف دون اتصال من إعدادات النظام." else "Offline voice pack for this language is not installed on this device image."
            else -> if (isAr) "تنبيه محرك الصوت المحلي (رمز $errorCode): يمكنك تجربة الأوامر مباشرة عبر شريط الإدخال أو الأزرار السريعة." else "Local speech engine notice (code $errorCode): You can also test commands directly via the quick deck or input bar."
        }
    }
}
