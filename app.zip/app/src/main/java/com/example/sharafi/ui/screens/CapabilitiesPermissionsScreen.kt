package com.example.sharafi.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.sharafi.domain.executor.DeviceCapabilitiesSnapshot
import com.example.sharafi.domain.executor.InstalledAppSummary
import com.example.sharafi.domain.nlu.CommandModulePlugin
import com.example.ui.theme.AmberAlert
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianDeep
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent

@Composable
fun CapabilitiesPermissionsScreen(
    isArabic: Boolean,
    capabilities: DeviceCapabilitiesSnapshot,
    installedApps: List<InstalledAppSummary>,
    registeredModules: List<CommandModulePlugin>,
    onRequestRecordAudioPermission: () -> Unit,
    onRequestCallPhonePermission: () -> Unit,
    onRequestNotificationsPermission: () -> Unit,
    onRefreshCapabilities: () -> Unit,
    onExecuteSampleCommand: (String) -> Unit,
    onBackToCenter: () -> Unit
) {
    BackHandler { onBackToCenter() }
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDeep)
            .testTag("capabilities_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isArabic) "الصلاحيات وقدرات النظام المحلية" else "Permissions & System Capabilities",
                        style = MaterialTheme.typography.headlineMedium,
                        color = CyanGlow,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isArabic) {
                            "فحص حي لجميع صلاحيات أندرويد ووحدات التحكم المتاحة بدون إنترنت."
                        } else {
                            "Live diagnostics of Android hardware permissions, system bridges, and NLU command plugins."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                IconButton(
                    onClick = onRefreshCapabilities,
                    modifier = Modifier.testTag("refresh_capabilities_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = if (isArabic) "تحديث الحالة" else "Refresh Status",
                        tint = CyanGlow
                    )
                }
            }
        }

        // 1. Android Permissions & System Bridges
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (isArabic) "صلاحيات أندرويد الأساسية والاختيارية" else "Android Permissions & System Bridges",
                        style = MaterialTheme.typography.titleMedium,
                        color = TurquoiseAccent,
                        fontWeight = FontWeight.Bold
                    )

                    CapabilityRowItem(
                        icon = Icons.Default.Mic,
                        title = if (isArabic) "صلاحية الميكروفون (RECORD_AUDIO)" else "Microphone Access (RECORD_AUDIO)",
                        subtitle = if (isArabic) {
                            "مطلوبة للتعرف على الكلام محلياً على الجهاز دون إنترنت."
                        } else {
                            "Required for on-device offline speech recognition."
                        },
                        isGranted = capabilities.recordAudioGranted,
                        actionLabel = if (isArabic) "منح الصلاحية" else "Grant Access",
                        onActionClick = onRequestRecordAudioPermission
                    )

                    CapabilityRowItem(
                        icon = Icons.Default.Phone,
                        title = if (isArabic) "الاتصال الهاتفي المباشر (CALL_PHONE)" else "Direct Phone Calling (CALL_PHONE)",
                        subtitle = if (isArabic) {
                            "اختيارية: تتيح إجراء المكالمة بعد نافذة التأكيد (أو فتح لوحة الاتصال كبديل آمن)."
                        } else {
                            "Optional: Places calls after confirmation dialog (otherwise opens Dialer safely)."
                        },
                        isGranted = capabilities.callPhoneGranted,
                        actionLabel = if (isArabic) "منح الصلاحية" else "Grant Access",
                        onActionClick = onRequestCallPhonePermission
                    )

                    CapabilityRowItem(
                        icon = Icons.Default.DoNotDisturbOn,
                        title = if (isArabic) "التحكم بوضع عدم الإزعاج والصامت" else "Do Not Disturb / Silent Policy",
                        subtitle = if (isArabic) {
                            "تسمح بتحويل الرنين إلى الصامت التام صوتياً."
                        } else {
                            "Allows switching ringer to full Silent mode via voice."
                        },
                        isGranted = capabilities.dndPolicyGranted,
                        actionLabel = if (isArabic) "فتح الإعدادات" else "Open Policy",
                        onActionClick = {
                            try {
                                context.startActivity(
                                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (_: Exception) {
                            }
                        }
                    )

                    CapabilityRowItem(
                        icon = Icons.Default.AccessibilityNew,
                        title = if (isArabic) "جسر إمكانية الوصول (التنقل الشامل)" else "SHARAFI Accessibility Navigation Bridge",
                        subtitle = if (isArabic) {
                            "اختيارية: لتنفيذ (رجوع، الشاشة الرئيسية، التطبيقات الأخيرة، الإشعارات، قفل الشاشة)."
                        } else {
                            "Optional user-enabled service for Back, Home, Recents, Notifications & Lock Screen."
                        },
                        isGranted = capabilities.accessibilityEnabled,
                        actionLabel = if (isArabic) "إعدادات الوصول" else "Enable Service",
                        onActionClick = {
                            try {
                                context.startActivity(
                                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (_: Exception) {
                            }
                        }
                    )

                    CapabilityRowItem(
                        icon = Icons.Default.NotificationsActive,
                        title = if (isArabic) "إشعارات الجلسة الصوتية بالخلفية" else "Foreground Session Notifications",
                        subtitle = if (isArabic) {
                            "لعرض إشعار الخدمة الأمامية عند تفعيل الاستماع الاختياري بالخلفية."
                        } else {
                            "Required on Android 13+ when running the optional foreground voice session."
                        },
                        isGranted = capabilities.postNotificationsGranted,
                        actionLabel = if (isArabic) "منح الصلاحية" else "Grant Access",
                        onActionClick = onRequestNotificationsPermission
                    )

                    CapabilityRowItem(
                        icon = Icons.Default.FlashlightOn,
                        title = if (isArabic) "وحدة الفلاش الخلفي (Camera Torch)" else "Rear LED Flashlight Hardware",
                        subtitle = if (capabilities.hasFlashlightHardware) {
                            if (isArabic) "وحدة الفلاش متوفرة وجاهزة للتحكم الصوتي." else "Hardware flash unit detected and ready."
                        } else {
                            if (isArabic) "غير متوفرة على هذا الجهاز/المحاكي." else "Not reported on this device/emulator."
                        },
                        isGranted = capabilities.hasFlashlightHardware,
                        actionLabel = if (isArabic) "تجربة الكشاف" else "Test Torch",
                        onActionClick = {
                            onExecuteSampleCommand(if (isArabic) "بدل حالة الكشاف" else "Toggle flashlight")
                        }
                    )
                }
            }
        }

        // 2. Installed Launchable Applications Discovery
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Apps,
                                contentDescription = null,
                                tint = CyanGlow
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isArabic) {
                                    "التطبيقات المكتشفة محلياً (${installedApps.size})"
                                } else {
                                    "Discovered Launchable Apps (${installedApps.size})"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = if (isArabic) {
                            "اضغط على أي تطبيق لفتحه عبر محرك الأوامر الصوتي، أو قل: \"افتح [اسم التطبيق]\"."
                        } else {
                            "Tap any installed app below to launch it via the command engine, or say: \"Open [App Name]\"."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    installedApps.take(10).forEach { app ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onExecuteSampleCommand(
                                        if (isArabic) "افتح تطبيق ${app.label}" else "Open ${app.label}"
                                    )
                                    onBackToCenter()
                                },
                            color = ObsidianSurface,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, BorderSubtle)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = app.label,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = app.packageName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextMuted
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = CyanGlow
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Modular Command Registry Plugins Overview
        item {
            Text(
                text = if (isArabic) {
                    "وحدات فهم الأوامر المسجلة (${registeredModules.size} وحدات برمجية)"
                } else {
                    "Registered NLU Command Modules (${registeredModules.size} Plugins)"
                },
                style = MaterialTheme.typography.titleLarge,
                color = CyanGlow,
                fontWeight = FontWeight.Bold
            )
        }

        items(registeredModules, key = { it.pluginId }) { module ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Extension,
                            contentDescription = null,
                            tint = TurquoiseAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) module.category.titleAr else module.category.titleEn,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "[${module.pluginId}]",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    val examples = if (isArabic) module.supportedActionsSummaryAr else module.supportedActionsSummaryEn
                    examples.forEach { ex ->
                        Text(
                            text = "• $ex",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CapabilityRowItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isGranted: Boolean,
    actionLabel: String,
    onActionClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = ObsidianSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (isGranted) EmeraldSuccess.copy(alpha = 0.4f) else BorderSubtle)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isGranted) EmeraldSuccess else AmberAlert,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = if (isGranted) EmeraldSuccess else AmberAlert,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (!isGranted) {
                Button(
                    onClick = onActionClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanContainer,
                        contentColor = CyanGlow
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = actionLabel, style = MaterialTheme.typography.labelMedium)
                }
            } else {
                OutlinedButton(
                    onClick = onActionClick,
                    border = BorderStroke(1.dp, ObsidianElevated),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = actionLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
