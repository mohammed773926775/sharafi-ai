package com.example.sharafi.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SharafiRepository(private val dao: SharafiDao) {

    val historyFlow: Flow<List<CommandHistoryEntity>> = dao.observeHistory()
    val customCommandsFlow: Flow<List<CustomCommandEntity>> = dao.observeCustomCommands()
    val settingsFlow: Flow<AssistantSettingsEntity> = dao.observeSettings().map {
        it ?: AssistantSettingsEntity()
    }

    suspend fun ensureDefaultsSeeded() {
        val currentSettings = dao.getSettingsOnce()
        if (currentSettings == null) {
            dao.saveSettings(AssistantSettingsEntity())
        }
        if (dao.getCustomCommandCount() == 0) {
            val defaults = listOf(
                CustomCommandEntity(
                    title = "وضع النوم / Sleep Mode",
                    triggerPhrases = "وضع النوم, وقت النوم, تصبح على خير, sleep mode, bedtime, good night",
                    actionPipeline = "اطفئ الكشاف ثم وضع الصامت ثم اضبط منبه على الساعة 7 صباحا",
                    description = "Turns off flashlight, activates silent/vibrate audio profile, and prepares morning alarm."
                ),
                CustomCommandEntity(
                    title = "وضع القيادة / Driving Mode",
                    triggerPhrases = "وضع القيادة, انا اقود, شغل وضع السيارة, driving mode, car mode",
                    actionPipeline = "ارفع الصوت الى 85 ثم افتح اعدادات البلوتوث",
                    description = "Sets media/system volume to 85% and opens Bluetooth connectivity for car audio."
                ),
                CustomCommandEntity(
                    title = "فحص الجهاز / System Diagnostic",
                    triggerPhrases = "فحص شامل, تقرير الجهاز, حالة الهاتف, system diagnostic, full status report, health check",
                    actionPipeline = "كم نسبة البطارية ثم مساحة التخزين المتبقية ثم كم الساعة الان",
                    description = "Executes a multi-step local telemetry inspection (Battery, Storage/RAM, and Time)."
                ),
                CustomCommandEntity(
                    title = "وضع التركيز / Study Focus",
                    triggerPhrases = "وضع التركيز, وضع الدراسة, ابدا المذاكرة, study mode, focus session",
                    actionPipeline = "وضع الاهتزاز ثم اضبط مؤقت لمدة 25 دقيقة",
                    description = "Switches phone to vibrate mode and starts a 25-minute Pomodoro countdown timer."
                ),
                CustomCommandEntity(
                    title = "اضاءة طوارئ / Emergency Light",
                    triggerPhrases = "طوارئ اضاءة, انقطع الكهرباء, ظلام, emergency light, blackout mode",
                    actionPipeline = "شغل الفلاش ثم كم نسبة البطارية",
                    description = "Activates the rear LED flashlight immediately and reports remaining battery percentage."
                )
            )
            defaults.forEach { dao.insertCustomCommand(it) }
        }
    }

    suspend fun logCommandHistory(entry: CommandHistoryEntity): Long {
        return dao.insertHistory(entry)
    }

    suspend fun toggleHistoryFavorite(id: Long, isFavorite: Boolean) {
        dao.setHistoryFavorite(id, isFavorite)
    }

    suspend fun deleteHistoryItem(id: Long) {
        dao.deleteHistoryItem(id)
    }

    suspend fun clearAllHistory() {
        dao.clearAllHistory()
    }

    suspend fun getEnabledCustomCommands(): List<CustomCommandEntity> {
        return dao.getEnabledCustomCommands()
    }

    suspend fun saveCustomCommand(command: CustomCommandEntity): Long {
        return if (command.id == 0L) {
            dao.insertCustomCommand(command)
        } else {
            dao.updateCustomCommand(command)
            command.id
        }
    }

    suspend fun setCustomCommandEnabled(id: Long, enabled: Boolean) {
        dao.setCustomCommandEnabled(id, enabled)
    }

    suspend fun incrementCustomCommandUsage(id: Long) {
        dao.incrementCustomCommandUsage(id)
    }

    suspend fun deleteCustomCommand(id: Long) {
        dao.deleteCustomCommand(id)
    }

    suspend fun getSettingsOnce(): AssistantSettingsEntity {
        return dao.getSettingsOnce() ?: AssistantSettingsEntity()
    }

    suspend fun updateSettings(transform: (AssistantSettingsEntity) -> AssistantSettingsEntity) {
        val current = getSettingsOnce()
        dao.saveSettings(transform(current))
    }
}
