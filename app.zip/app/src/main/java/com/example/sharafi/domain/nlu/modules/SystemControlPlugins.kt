package com.example.sharafi.domain.nlu.modules

import com.example.sharafi.domain.nlu.AssistantLanguage
import com.example.sharafi.domain.nlu.CommandCategory
import com.example.sharafi.domain.nlu.CommandModulePlugin
import com.example.sharafi.domain.nlu.ParsedCommandIntent
import com.example.sharafi.domain.nlu.TextNormalizer

class HardwareFlashlightPlugin : CommandModulePlugin {
    override val pluginId: String = "hardware_flashlight"
    override val category: CommandCategory = CommandCategory.HARDWARE_CONTROL
    override val supportedActionsSummaryAr: List<String> = listOf(
        "شغل الفلاش / افتح الكشاف / نور الكشاف",
        "اطفئ الفلاش / اغلق الكشاف",
        "بدل حالة الكشاف"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Turn on flashlight / Enable torch / Light on",
        "Turn off flashlight / Disable torch / Light off",
        "Toggle flashlight"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        val hasFlashWord = listOf(
            "فلاش", "الفلاش", "كشاف", "الكشاف", "نور", "النور", "اضاءه خلف", "ضوء الكاميرا",
            "flashlight", "torch", "flash light", "back light"
        ).any { normalizedSegment.contains(it) }

        if (!hasFlashWord) return null

        val isOff = listOf(
            "اطف", "طف", "اغلق", "قفل", "وقف", "سكر", "اوقف",
            "off", "disable", "stop", "kill", "close", "shut"
        ).any { normalizedSegment.contains(it) }

        val isToggle = listOf("بدل", "عكس", "تبديل", "toggle", "switch").any { normalizedSegment.contains(it) }

        val actionId = when {
            isOff -> "FLASHLIGHT_OFF"
            isToggle -> "FLASHLIGHT_TOGGLE"
            else -> "FLASHLIGHT_ON"
        }

        return ParsedCommandIntent(
            pluginId = pluginId,
            actionId = actionId,
            category = category,
            rawSegment = rawSegment,
            normalizedSegment = normalizedSegment,
            language = language
        )
    }
}

class AudioVolumePlugin : CommandModulePlugin {
    override val pluginId: String = "audio_volume"
    override val category: CommandCategory = CommandCategory.AUDIO_VOLUME
    override val supportedActionsSummaryAr: List<String> = listOf(
        "ارفع الصوت / علي الصوت / ارفع الصوت إلى 80%",
        "خفض الصوت / وطي الصوت",
        "وضع الصامت / اكتم الصوت / وضع الاهتزاز / الوضع العام"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Increase volume / Louder / Set volume to 75%",
        "Decrease volume / Lower volume / Quieter",
        "Silent mode / Mute audio / Vibrate mode / Normal ring mode"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        // Check Ringer Mode keywords first
        if (listOf("وضع الصامت", "الوضع الصامت", "صامت", "اكتم الصوت", "كتم الصوت", "silent mode", "mute phone", "mute audio", "silence phone")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "RINGER_SILENT",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("وضع الاهتزاز", "الوضع الهزاز", "هزاز", "اهتزاز", "vibrate mode", "vibration mode", "set to vibrate")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "RINGER_VIBRATE",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("الوضع العام", "وضع الرنين", "الغاء الصامت", "شغل الصوت", "فك الكتم", "normal mode", "ring mode", "unmute")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "RINGER_NORMAL",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        val hasVolumeWord = listOf(
            "صوت", "الصوت", "مستوى الصوت", "volume", "sound level", "louder", "quieter", "audio"
        ).any { normalizedSegment.contains(it) }

        if (!hasVolumeWord) return null

        val number = TextNormalizer.extractFirstNumber(normalizedSegment)
        if (number != null) {
            val clamped = number.coerceIn(0, 100)
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "VOLUME_SET",
                category = category,
                parameters = mapOf("level" to clamped.toString()),
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("اعلي", "اقصي", "كامل", "فل", "الحد الاقصي", "max", "maximum", "full").any { normalizedSegment.contains(it) }) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "VOLUME_SET",
                category = category,
                parameters = mapOf("level" to "100"),
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        if (listOf("نصف", "نص", "متوسط", "وسط", "half", "medium", "middle").any { normalizedSegment.contains(it) }) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "VOLUME_SET",
                category = category,
                parameters = mapOf("level" to "50"),
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        val isDown = listOf("خفض", "وطي", "نقص", "قلل", "هدي", "اخفض", "down", "lower", "decrease", "quieter", "reduce")
            .any { normalizedSegment.contains(it) }
        if (isDown) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "VOLUME_DOWN",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        val isUp = listOf("ارفع", "علي", "زيد", "رفع", "قوي", "اعلي", "up", "increase", "raise", "louder", "boost")
            .any { normalizedSegment.contains(it) }
        if (isUp) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "VOLUME_UP",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        return null
    }
}

class SystemSettingsPlugin : CommandModulePlugin {
    override val pluginId: String = "system_settings"
    override val category: CommandCategory = CommandCategory.SYSTEM_SETTINGS
    override val supportedActionsSummaryAr: List<String> = listOf(
        "افتح إعدادات الواي فاي / شغل الواي فاي",
        "افتح إعدادات البلوتوث / وضع الطيران / الموقع GPS",
        "إعدادات الشاشة والسطوع / البطارية / التخزين / اللغة / إمكانية الوصول"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Open Wi-Fi settings / Enable Wi-Fi",
        "Open Bluetooth / Airplane mode / Location GPS settings",
        "Display & Brightness / Battery / Storage / Language / Accessibility settings"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        // Avoid intercepting telemetry questions like "هل الواي فاي متصل" or "كم نسبة البطارية"
        val isTelemetryQuestion = listOf("كم ", "ما هي ", "ما هو ", "هل ", "حاله ", "نسبه ", "مساحه ", "how much", "what is", "status of", "level")
            .any { normalizedSegment.startsWith(it) || normalizedSegment.contains(it) } &&
            !listOf("افتح", "شغل", "اطف", "اعدادات", "ضبط", "open", "turn", "settings", "enable", "disable").any { normalizedSegment.contains(it) }

        if (isTelemetryQuestion) return null

        val targetSetting = when {
            listOf("واي فاي", "وايفاي", "الشبكه اللاسلكيه", "wifi", "wi fi", "wireless").any { normalizedSegment.contains(it) } -> "WIFI"
            listOf("بلوتوث", "البلوتوث", "bluetooth").any { normalizedSegment.contains(it) } -> "BLUETOOTH"
            listOf("وضع الطيران", "طيران", "airplane", "flight mode").any { normalizedSegment.contains(it) } -> "AIRPLANE"
            listOf("الموقع", "جي بي اس", "خرائط الموقع", "location", "gps").any { normalizedSegment.contains(it) } &&
                listOf("اعدادات", "ضبط", "شغل", "اطف", "افتح", "settings", "turn", "enable", "disable").any { normalizedSegment.contains(it) } -> "LOCATION"
            listOf("السطوع", "اضاءه الشاشه", "اعدادات الشاشه", "brightness", "display settings", "screen timeout").any { normalizedSegment.contains(it) } -> "DISPLAY"
            listOf("توفير الطاقه", "موفر البطاريه", "اعدادات البطاريه", "battery saver", "power saving", "battery settings").any { normalizedSegment.contains(it) } -> "BATTERY_SAVER"
            listOf("اعدادات التخزين", "اداره التخزين", "storage settings").any { normalizedSegment.contains(it) } -> "STORAGE"
            listOf("اعدادات الصوت", "نغمه الرنين", "sound settings", "ringtone settings").any { normalizedSegment.contains(it) } -> "SOUND"
            listOf("امكانيه الوصول", "خدمات الوصول", "accessibility").any { normalizedSegment.contains(it) } -> "ACCESSIBILITY"
            listOf("اعدادات اللغه", "تغيير اللغه", "language settings").any { normalizedSegment.contains(it) } -> "LANGUAGE"
            listOf("بيانات الهاتف", "بيانات الجوال", "انترنت الشريحه", "mobile data", "cellular data", "data roaming").any { normalizedSegment.contains(it) } -> "DATA_ROAMING"
            listOf("نقطه اتصال", "بث شبكه", "هوت سبوت", "hotspot", "tethering").any { normalizedSegment.contains(it) } -> "TETHERING"
            listOf("الامان", "قفل البصمه", "كلمه المرور", "security settings", "biometrics").any { normalizedSegment.contains(it) } -> "SECURITY"
            listOf("افتح الاعدادات", "افتح الضبط", "اعدادات الجهاز", "الضبط", "open settings", "system settings", "device settings")
                .any { normalizedSegment == it || normalizedSegment.contains(it) } -> "MAIN_SETTINGS"
            else -> null
        } ?: return null

        val desiredState = when {
            listOf("اطف", "طف", "اغلق", "وقف", "عطل", "off", "disable").any { normalizedSegment.contains(it) } -> "OFF"
            listOf("شغل", "فعل", "افتح", "on", "enable", "open").any { normalizedSegment.contains(it) } -> "ON"
            else -> "OPEN"
        }

        return ParsedCommandIntent(
            pluginId = pluginId,
            actionId = "OPEN_SETTING_$targetSetting",
            category = category,
            parameters = mapOf("target" to targetSetting, "desiredState" to desiredState),
            rawSegment = rawSegment,
            normalizedSegment = normalizedSegment,
            language = language
        )
    }
}

class AlarmsTimersPlugin : CommandModulePlugin {
    override val pluginId: String = "alarms_timers"
    override val category: CommandCategory = CommandCategory.ALARMS_TIMERS
    override val supportedActionsSummaryAr: List<String> = listOf(
        "اضبط منبه على الساعة 7:30 صباحاً / صحيني الساعة 6",
        "اضبط مؤقت لمدة 10 دقائق / تايمر 30 ثانية",
        "اعرض المنبهات"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Set alarm for 7:30 AM / Wake me up at 6",
        "Set timer for 10 minutes / Countdown 45 seconds",
        "Show my alarms"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        val isShowAlarms = listOf("اعرض المنبهات", "افتح المنبهات", "كل المنبهات", "show alarms", "view alarms", "open alarms")
            .any { normalizedSegment.contains(it) }
        if (isShowAlarms) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "SHOW_ALARMS",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        val hasTimerWord = listOf("مؤقت", "موؤقت", "تايمر", "عداد تنازلي", "timer", "countdown").any { normalizedSegment.contains(it) }
        if (hasTimerWord) {
            val numbers = Regex("(\\d+)").findAll(normalizedSegment).mapNotNull { it.value.toIntOrNull() }.toList()
            if (numbers.isEmpty()) {
                return ParsedCommandIntent(
                    pluginId = pluginId,
                    actionId = "SET_TIMER",
                    category = category,
                    rawSegment = rawSegment,
                    normalizedSegment = normalizedSegment,
                    language = language,
                    clarificationPromptAr = "كم مدة المؤقت التي تريد ضبطها؟ (مثلاً: 5 دقائق أو 15 دقيقة)",
                    clarificationPromptEn = "How long should I set the timer for? (e.g., 5 minutes or 15 minutes)",
                    clarificationOptions = listOf("5 دقائق / 5 min", "10 دقائق / 10 min", "15 دقيقة / 15 min", "25 دقيقة / 25 min")
                )
            }

            val baseVal = numbers.first()
            val isHours = listOf("ساعه", "ساعات", "hour", "hours", "hr").any { normalizedSegment.contains(it) }
            val isSeconds = listOf("ثانيه", "ثواني", "ثوان", "second", "seconds", "sec").any { normalizedSegment.contains(it) }
            val seconds = when {
                isHours -> baseVal * 3600
                isSeconds -> baseVal
                else -> baseVal * 60
            }

            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "SET_TIMER",
                category = category,
                parameters = mapOf(
                    "seconds" to seconds.toString(),
                    "displayAmount" to baseVal.toString(),
                    "unit" to when {
                        isHours -> "HOURS"
                        isSeconds -> "SECONDS"
                        else -> "MINUTES"
                    }
                ),
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        val hasAlarmWord = listOf("منبه", "المنبه", "صحيني", "ايقظني", "ذكرني الساعه", "alarm", "wake me up").any { normalizedSegment.contains(it) }
        if (hasAlarmWord) {
            // Check for HH:MM or numbers
            val colonTime = Regex("(\\d{1,2})[:\\s](\\d{1,2})").find(normalizedSegment)
            val numbers = Regex("(\\d+)").findAll(normalizedSegment).mapNotNull { it.value.toIntOrNull() }.toList()

            if (numbers.isEmpty()) {
                return ParsedCommandIntent(
                    pluginId = pluginId,
                    actionId = "SET_ALARM",
                    category = category,
                    rawSegment = rawSegment,
                    normalizedSegment = normalizedSegment,
                    language = language,
                    clarificationPromptAr = "في أي ساعة تريد ضبط المنبه؟",
                    clarificationPromptEn = "What time would you like to set the alarm for?",
                    clarificationOptions = listOf("اضبط منبه الساعة 6 صباحا", "اضبط منبه الساعة 7 صباحا", "اضبط منبه الساعة 8 صباحا")
                )
            }

            var hour = colonTime?.groupValues?.get(1)?.toIntOrNull() ?: numbers.first()
            var minute = colonTime?.groupValues?.get(2)?.toIntOrNull() ?: numbers.getOrNull(1) ?: 0

            if (listOf("ونصف", "ونص", "half past").any { normalizedSegment.contains(it) } && minute == 0) {
                minute = 30
            } else if (listOf("وربع", "quarter past").any { normalizedSegment.contains(it) } && minute == 0) {
                minute = 15
            }

            val isPm = listOf("مساء", "ليل", "عصرا", "ظهرا", "pm", "tonight", "evening", "afternoon").any { normalizedSegment.contains(it) }
            val isAm = listOf("صباحا", "الفجر", "الصبح", "am", "morning").any { normalizedSegment.contains(it) }

            if (isPm && hour in 1..11) {
                hour += 12
            } else if (isAm && hour == 12) {
                hour = 0
            }

            hour = hour.coerceIn(0, 23)
            minute = minute.coerceIn(0, 59)

            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "SET_ALARM",
                category = category,
                parameters = mapOf(
                    "hour" to hour.toString(),
                    "minute" to minute.toString()
                ),
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        return null
    }
}

class AppManagementPlugin : CommandModulePlugin {
    override val pluginId: String = "app_management"
    override val category: CommandCategory = CommandCategory.APP_MANAGEMENT
    override val supportedActionsSummaryAr: List<String> = listOf(
        "افتح تطبيق [اسم التطبيق] (واتساب، يوتيوب، الحاسبة، الساعة، الخرائط، المتصفح...)",
        "اعرض التطبيقات المثبتة / كم عدد التطبيقات"
    )
    override val supportedActionsSummaryEn: List<String> = listOf(
        "Open / Launch [App Name] (WhatsApp, YouTube, Calculator, Clock, Maps, Browser...)",
        "List installed apps / Count installed applications"
    )

    override fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent? {
        if (listOf("التطبيقات المثبته", "عدد التطبيقات", "قائمه التطبيقات", "installed apps", "list apps", "how many apps")
                .any { normalizedSegment.contains(it) }
        ) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "LIST_INSTALLED_APPS",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language
            )
        }

        // Check if user only said "افتح" or "افتح تطبيق" or "open" or "open app"
        if (normalizedSegment in listOf("افتح", "شغل", "افتح تطبيق", "شغل برنامج", "open", "launch", "open app", "launch app", "start app")) {
            return ParsedCommandIntent(
                pluginId = pluginId,
                actionId = "OPEN_APP",
                category = category,
                rawSegment = rawSegment,
                normalizedSegment = normalizedSegment,
                language = language,
                clarificationPromptAr = "أي تطبيق ترغب في فتحه؟",
                clarificationPromptEn = "Which application would you like to open?",
                clarificationOptions = listOf("افتح الإعدادات", "افتح الكاميرا", "افتح الساعة", "افتح الحاسبة", "افتح المتصفح")
            )
        }

        val openPrefixes = listOf(
            "افتح تطبيق ", "شغل تطبيق ", "افتح برنامج ", "شغل برنامج ", "ادخل علي تطبيق ", "ادخل علي ", "افتح ", "شغل ",
            "open application ", "launch application ", "open app ", "launch app ", "start app ", "open ", "launch "
        )

        val matchedPrefix = openPrefixes.firstOrNull { normalizedSegment.startsWith(it) } ?: return null
        val targetAppQuery = normalizedSegment.removePrefix(matchedPrefix).trim()

        // Do not intercept if targetAppQuery is a system hardware/settings keyword handled by earlier modules
        val reservedKeywords = listOf(
            "الفلاش", "فلاش", "الكشاف", "كشاف", "الواي فاي", "واي فاي", "البلوتوث", "بلوتوث",
            "الاشعارات", "اشعارات", "الكاميرا الاماميه", "فيديو",
            "flashlight", "torch", "wifi", "bluetooth", "notifications", "quick settings"
        )
        if (targetAppQuery.isBlank() || reservedKeywords.any { targetAppQuery == it }) return null

        return ParsedCommandIntent(
            pluginId = pluginId,
            actionId = "OPEN_APP",
            category = category,
            parameters = mapOf("appQuery" to targetAppQuery),
            rawSegment = rawSegment,
            normalizedSegment = normalizedSegment,
            language = language
        )
    }
}
