package com.example.sharafi.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesomeMotion
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.sharafi.data.CustomCommandEntity
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CoralDanger
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianDeep
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import com.example.ui.theme.TurquoiseContainer

@Composable
fun CustomCommandsScreen(
    isArabic: Boolean,
    customCommands: List<CustomCommandEntity>,
    onSaveCommand: (Long, String, String, String, String) -> Unit,
    onToggleEnabled: (CustomCommandEntity) -> Unit,
    onDeleteCommand: (Long) -> Unit,
    onRunMacroNow: (CustomCommandEntity) -> Unit,
    onBackToCenter: () -> Unit
) {
    BackHandler { onBackToCenter() }

    var showDialog by rememberSaveable { mutableStateOf(false) }
    var editingId by rememberSaveable { mutableLongStateOf(0L) }
    var titleInput by rememberSaveable { mutableStateOf("") }
    var triggersInput by rememberSaveable { mutableStateOf("") }
    var pipelineInput by rememberSaveable { mutableStateOf("") }
    var descInput by rememberSaveable { mutableStateOf("") }

    fun openCreateDialog() {
        editingId = 0L
        titleInput = ""
        triggersInput = ""
        pipelineInput = ""
        descInput = ""
        showDialog = true
    }

    fun openEditDialog(item: CustomCommandEntity) {
        editingId = item.id
        titleInput = item.title
        triggersInput = item.triggerPhrases
        pipelineInput = item.actionPipeline
        descInput = item.description
        showDialog = true
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDeep)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("custom_commands_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isArabic) "الأوامر المخصصة والماكرو الصوتي" else "Custom Voice Commands & Macros",
                    style = MaterialTheme.typography.headlineMedium,
                    color = CyanGlow,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isArabic) {
                        "أنشئ عباراتك الخاصة لتنفيذ إجراء واحد أو سلسلة أوامر متتالية بضغطة أو بكلمة واحدة."
                    } else {
                        "Bind custom Arabic or English phrases to single actions or multi-step command chains."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = { openCreateDialog() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanGlow,
                    contentColor = ObsidianDeep
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("add_custom_command_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isArabic) "أمر جديد" else "New Macro",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(customCommands, key = { it.id }) { command ->
                CustomMacroCard(
                    command = command,
                    isArabic = isArabic,
                    onToggleEnabled = { onToggleEnabled(command) },
                    onEdit = { openEditDialog(command) },
                    onDelete = { onDeleteCommand(command.id) },
                    onRunNow = {
                        onRunMacroNow(command)
                        onBackToCenter()
                    }
                )
            }
        }
    }

    if (showDialog) {
        val actionBuildingBlocks = listOf(
            "شغل الفلاش",
            "اطفئ الكشاف",
            "ارفع الصوت الى 80",
            "وضع الاهتزاز",
            "وضع الصامت",
            "كم نسبة البطارية",
            "مساحة التخزين المتبقية",
            "اضبط مؤقت لمدة 15 دقيقة",
            "افتح اعدادات البلوتوث"
        )

        AlertDialog(
            onDismissRequest = { showDialog = false },
            containerColor = ObsidianCard,
            titleContentColor = CyanGlow,
            textContentColor = TextPrimary,
            title = {
                Text(
                    text = if (editingId == 0L) {
                        if (isArabic) "إنشاء أمر صوتي مخصص" else "Create Custom Voice Macro"
                    } else {
                        if (isArabic) "تعديل الأمر المخصص" else "Edit Custom Voice Macro"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text(if (isArabic) "عنوان الأمر (مثال: وضع القراءة)" else "Macro Title (e.g. Reading Mode)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("macro_title_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanGlow,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = triggersInput,
                        onValueChange = { triggersInput = it },
                        label = {
                            Text(
                                if (isArabic) {
                                    "عبارات التفعيل الصوتية (افصل بينها بفاصلة ,)"
                                } else {
                                    "Voice Trigger Phrases (comma-separated)"
                                }
                            )
                        },
                        placeholder = {
                            Text(
                                if (isArabic) "وضع القراءة, وقت القراءة, reading mode" else "reading mode, quiet study",
                                color = TextMuted
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("macro_triggers_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanGlow,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = pipelineInput,
                        onValueChange = { pipelineInput = it },
                        label = {
                            Text(
                                if (isArabic) {
                                    "سلسلة الإجراءات (استخدم 'ثم' أو ';' للربط بين عدة أوامر)"
                                } else {
                                    "Action Pipeline (connect multiple commands with 'then' or ';')"
                                }
                            )
                        },
                        placeholder = {
                            Text(
                                if (isArabic) "وضع الاهتزاز ثم اضبط مؤقت لمدة 20 دقيقة" else "vibrate mode then set timer for 20 minutes",
                                color = TextMuted
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("macro_pipeline_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanGlow,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Text(
                        text = if (isArabic) "إضافة إجراء سريع للسلسلة:" else "Append quick action to pipeline:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TurquoiseAccent
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        actionBuildingBlocks.forEach { block ->
                            Surface(
                                modifier = Modifier.clickable {
                                    pipelineInput = if (pipelineInput.isBlank()) {
                                        block
                                    } else {
                                        "$pipelineInput ثم $block"
                                    }
                                },
                                color = ObsidianElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.3f))
                            ) {
                                Text(
                                    text = "+ $block",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text(if (isArabic) "وصف مختصر (اختياري)" else "Description (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanGlow,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (titleInput.isNotBlank() && triggersInput.isNotBlank() && pipelineInput.isNotBlank()) {
                            onSaveCommand(editingId, titleInput, triggersInput, pipelineInput, descInput)
                            showDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanGlow,
                        contentColor = ObsidianDeep
                    ),
                    modifier = Modifier.testTag("save_macro_confirm_button")
                ) {
                    Text(if (isArabic) "حفظ الأمر" else "Save Macro", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDialog = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun CustomMacroCard(
    command: CustomCommandEntity,
    isArabic: Boolean,
    onToggleEnabled: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRunNow: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (command.isEnabled) ObsidianCard else ObsidianSurface.copy(alpha = 0.6f)
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (command.isEnabled) CyanGlow.copy(alpha = 0.45f) else BorderSubtle
        ),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesomeMotion,
                        contentDescription = null,
                        tint = if (command.isEnabled) CyanGlow else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = command.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) "عدد مرات الاستخدام: ${command.usageCount}" else "Executed ${command.usageCount} times",
                            style = MaterialTheme.typography.labelSmall,
                            color = TurquoiseAccent
                        )
                    }
                }

                Switch(
                    checked = command.isEnabled,
                    onCheckedChange = { onToggleEnabled() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = ObsidianDeep,
                        checkedTrackColor = CyanGlow
                    )
                )
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = ObsidianSurface,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, BorderSubtle)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = if (isArabic) "عبارات التفعيل الصوتية:" else "Spoken Triggers:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = command.triggerPhrases,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyanGlow,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isArabic) "الإجراءات المنفذة:" else "Action Pipeline:",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                    Text(
                        text = command.actionPipeline,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                }
            }

            if (command.description.isNotBlank()) {
                Text(
                    text = command.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onEdit) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = if (isArabic) "تعديل" else "Edit",
                            tint = TextSecondary
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = if (isArabic) "حذف" else "Delete",
                            tint = CoralDanger.copy(alpha = 0.85f)
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .clickable { onRunNow() }
                        .testTag("run_macro_${command.id}"),
                    color = TurquoiseContainer,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, TurquoiseAccent)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = TurquoiseAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isArabic) "تشغيل الماكرو الآن" else "Run Macro Now",
                            style = MaterialTheme.typography.labelLarge,
                            color = TurquoiseAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
