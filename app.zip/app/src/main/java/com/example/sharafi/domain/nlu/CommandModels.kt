package com.example.sharafi.domain.nlu

enum class AssistantLanguage(val code: String, val localeTag: String, val displayNameAr: String, val displayNameEn: String) {
    AR("AR", "ar-SA", "العربية", "Arabic"),
    EN("EN", "en-US", "الإنجليزية", "English")
}

enum class CommandCategory(val titleAr: String, val titleEn: String) {
    HARDWARE_CONTROL("التحكم بالعتاد", "Hardware Control"),
    AUDIO_VOLUME("الصوت ومستوى الرنين", "Audio & Volume"),
    APP_MANAGEMENT("إدارة وتشغيل التطبيقات", "App Management"),
    SYSTEM_SETTINGS("إعدادات النظام والاتصال", "System & Connectivity"),
    ALARMS_TIMERS("المنبهات والمؤقتات", "Alarms & Timers"),
    CAMERA_MEDIA("الكاميرا والوسائط", "Camera & Media"),
    COMMUNICATION("الاتصال والرسائل", "Phone & Messages"),
    DEVICE_TELEMETRY("معلومات وحالة الجهاز", "Device Telemetry"),
    ACCESSIBILITY_NAV("التنقل والوصول السريع", "System Navigation"),
    UTILITY_CALC("الحسابات والأدوات", "Math & Utilities"),
    CUSTOM_MACRO("الأوامر المخصصة", "Custom Macros"),
    UNKNOWN("غير معروف", "Unrecognized")
}

enum class ExecutionOutcomeStatus {
    VERIFIED_SUCCESS,
    PARTIAL_SUCCESS,
    RESTRICTED_ALTERNATIVE,
    AWAITING_CONFIRMATION,
    NEEDS_CLARIFICATION,
    MISSING_PERMISSION,
    FAILED
}

data class ParsedCommandIntent(
    val pluginId: String,
    val actionId: String,
    val category: CommandCategory,
    val parameters: Map<String, String> = emptyMap(),
    val rawSegment: String,
    val normalizedSegment: String,
    val language: AssistantLanguage,
    val confidence: Float = 1.0f,
    val isSensitive: Boolean = false,
    val clarificationPromptAr: String? = null,
    val clarificationPromptEn: String? = null,
    val clarificationOptions: List<String> = emptyList()
) {
    val requiresClarification: Boolean
        get() = !clarificationPromptAr.isNullOrBlank() || !clarificationPromptEn.isNullOrBlank()
}

data class ActionExecutionResult(
    val status: ExecutionOutcomeStatus,
    val spokenResponseAr: String,
    val spokenResponseEn: String,
    val technicalDetail: String,
    val category: CommandCategory,
    val actionId: String,
    val requiredPermission: String? = null,
    val pendingIntentToConfirm: ParsedCommandIntent? = null,
    val pendingClarificationIntent: ParsedCommandIntent? = null
) {
    fun responseFor(language: AssistantLanguage): String {
        return if (language == AssistantLanguage.AR) spokenResponseAr else spokenResponseEn
    }
}

interface CommandModulePlugin {
    val pluginId: String
    val category: CommandCategory
    val supportedActionsSummaryAr: List<String>
    val supportedActionsSummaryEn: List<String>

    /**
     * Attempts to parse a single normalized command segment into a [ParsedCommandIntent].
     * Returns null if this module does not match the user's intent.
     */
    fun matchIntent(
        rawSegment: String,
        normalizedSegment: String,
        language: AssistantLanguage
    ): ParsedCommandIntent?
}
