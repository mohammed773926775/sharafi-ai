package com.example.sharafi.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MicExternalOn
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.sharafi.data.AssistantSettingsEntity
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyanContainer
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianDeep
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TurquoiseAccent
import java.util.Locale

@Composable
fun VoiceSettingsAndInfoScreen(
    isArabic: Boolean,
    settings: AssistantSettingsEntity,
    isForegroundServiceRunning: Boolean,
    ttsDiagnostic: String,
    onToggleUiLanguage: () -> Unit,
    onSelectRecognitionMode: (String) -> Unit,
    onToggleVoiceResponses: (Boolean) -> Unit,
    onSpeechRateChange: (Float) -> Unit,
    onSpeechPitchChange: (Float) -> Unit,
    onToggleStrictOffline: (Boolean) -> Unit,
    onToggleSensitiveGuard: (Boolean) -> Unit,
    onToggleHaptics: (Boolean) -> Unit,
    onToggleBackgroundService: (Boolean) -> Unit,
    onTestTtsVoice: () -> Unit,
    onBackToCenter: () -> Unit
) {
    BackHandler { onBackToCenter() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDeep)
            .testTag("settings_info_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = if (isArabic) "إعدادات الصوت واللغة ومعلومات النظام" else "Voice, Language & Architecture Info",
                style = MaterialTheme.typography.headlineMedium,
                color = CyanGlow,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isArabic) {
                    "تخصيص محرك النطق المحلي (TTS)، لغة التعرف الصوتي، الخصوصية، وتعليمات التثبيت."
                } else {
                    "Configure offline TextToSpeech, speech recognition locales, background session, and mobile APK guide."
                },
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        // 1. Voice & Language Configuration Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = CyanGlow
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "إعدادات اللغة والنطق المحلي (TTS & STT)" else "Offline Speech & Language Controls",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyanGlow,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // UI Language Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isArabic) "لغة الواجهة واتجاه التخطيط" else "Interface Language & Layout Direction",
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary
                            )
                            Text(
                                text = if (isArabic) "العربية (من اليمين لليسار RTL)" else "English (Left-to-Right LTR)",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Button(
                            onClick = onToggleUiLanguage,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanContainer,
                                contentColor = CyanGlow
                            ),
                            modifier = Modifier.testTag("settings_toggle_language_btn")
                        ) {
                            Text(if (isArabic) "Switch to English" else "التبديل للعربية")
                        }
                    }

                    // Recognition Locale Selector
                    Text(
                        text = if (isArabic) "وضع لغة التعرف على الصوت (SpeechRecognizer):" else "Speech Recognition Locale Mode:",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextPrimary
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "AUTO" to (if (isArabic) "تلقائي" else "Auto"),
                            "AR" to (if (isArabic) "العربية (ar-SA)" else "Arabic (ar-SA)"),
                            "EN" to (if (isArabic) "الإنجليزية (en-US)" else "English (en-US)")
                        ).forEach { (code, label) ->
                            FilterChip(
                                selected = settings.recognitionLanguageMode == code,
                                onClick = { onSelectRecognitionMode(code) },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanContainer,
                                    selectedLabelColor = CyanGlow
                                )
                            )
                        }
                    }

                    // Voice Responses Toggle
                    SettingsToggleRow(
                        title = if (isArabic) "تفعيل الردود الصوتية المسموعة (Offline TTS)" else "Enable Spoken Voice Responses (Offline TTS)",
                        subtitle = ttsDiagnostic,
                        checked = settings.voiceResponsesEnabled,
                        onCheckedChange = onToggleVoiceResponses
                    )

                    // Speech Rate Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isArabic) "سرعة النطق الصوتي" else "Speech Rate",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = String.format(Locale.US, "%.2fx", settings.speechRate),
                                style = MaterialTheme.typography.labelLarge,
                                color = CyanGlow
                            )
                        }
                        Slider(
                            value = settings.speechRate,
                            onValueChange = onSpeechRateChange,
                            valueRange = 0.6f..1.8f,
                            colors = SliderDefaults.colors(
                                thumbColor = CyanGlow,
                                activeTrackColor = CyanGlow
                            )
                        )
                    }

                    // Speech Pitch Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isArabic) "طبقة الصوت (Pitch)" else "Voice Pitch",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = String.format(Locale.US, "%.2fx", settings.speechPitch),
                                style = MaterialTheme.typography.labelLarge,
                                color = TurquoiseAccent
                            )
                        }
                        Slider(
                            value = settings.speechPitch,
                            onValueChange = onSpeechPitchChange,
                            valueRange = 0.6f..1.6f,
                            colors = SliderDefaults.colors(
                                thumbColor = TurquoiseAccent,
                                activeTrackColor = TurquoiseAccent
                            )
                        )
                    }

                    Button(
                        onClick = onTestTtsVoice,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_tts_sample_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanGlow,
                            contentColor = ObsidianDeep
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "اختبار الصوت المحلي الآن" else "Test Local Voice Synthesis Now",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 2. Privacy, Security & Optional Foreground Voice Activation
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, BorderSubtle),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = TurquoiseAccent
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "الخصوصية والأمان والعمل بالخلفية" else "Privacy, Security & Background Operation",
                            style = MaterialTheme.typography.titleMedium,
                            color = TurquoiseAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    SettingsToggleRow(
                        title = if (isArabic) "فرض التعرف الصوتي المحلي الصارم (EXTRA_PREFER_OFFLINE)" else "Enforce Strict On-Device Offline Recognition",
                        subtitle = if (isArabic) {
                            "يمنع إرسال أي مقاطع صوتية إلى خوادم خارجية نهائياً."
                        } else {
                            "Never uploads audio or silently switches to cloud recognition."
                        },
                        checked = settings.strictOfflineRecognition,
                        onCheckedChange = onToggleStrictOffline
                    )

                    SettingsToggleRow(
                        title = if (isArabic) "تأكيد المستخدم قبل المكالمات والرسائل" else "Confirm Before Calls & Messages",
                        subtitle = if (isArabic) {
                            "يطلب موافقة صريحة على الشاشة قبل تنفيذ أي اتصال أو رسالة نصية."
                        } else {
                            "Requires explicit user confirmation before executing sensitive communication actions."
                        },
                        checked = settings.requireSensitiveConfirmation,
                        onCheckedChange = onToggleSensitiveGuard
                    )

                    SettingsToggleRow(
                        title = if (isArabic) "الاهتزاز التفاعلي عند التقاط الأوامر" else "Haptic Feedback on Voice Commands",
                        subtitle = if (isArabic) "نبضة اهتزاز خفيفة عند بدء الاستماع وتنفيذ الأمر." else "Subtle tactile pulse when starting microphone or executing actions.",
                        checked = settings.hapticFeedbackEnabled,
                        onCheckedChange = onToggleHaptics
                    )

                    Surface(
                        color = ObsidianSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.MicExternalOn,
                                        contentDescription = null,
                                        tint = if (isForegroundServiceRunning) EmeraldSuccess else CyanGlow
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = if (isArabic) "جلسة التفعيل الصوتي بالخلفية (اختياري)" else "Background Voice Session Service (Optional)",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isArabic) {
                                                "تعمل كخدمة أمامية رسمية (Foreground Microphone Service) مع إشعار تحكم صريح وفق سياسات أندرويد 14+."
                                            } else {
                                                "Runs as an official Android Foreground Microphone Service with persistent stop control."
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary
                                        )
                                    }
                                }

                                Switch(
                                    checked = settings.backgroundListeningServiceEnabled || isForegroundServiceRunning,
                                    onCheckedChange = onToggleBackgroundService,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ObsidianDeep,
                                        checkedTrackColor = EmeraldSuccess
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Architecture & Mobile-Only APK Installation Guide
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, CyanGlow.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Architecture,
                            contentDescription = null,
                            tint = CyanGlow
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "البنية المعمارية لـ SHARAFI AI (100% محلي)" else "SHARAFI AI Offline Architecture",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyanGlow,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (isArabic) {
                            "• معرف الحزمة: com.sharafi.offlineassistant\n" +
                                "• صفر اتصال بالإنترنت: التطبيق لا يطلب صلاحية android.permission.INTERNET إطلاقاً.\n" +
                                "• الطبقات السبع: محرك التعرف الصوتي المحلي ← مطبّع النصوص العربي/الإنجليزي ← مصنف النوايا والأوامر المتعددة ← سجل الإضافات القابل للتوسعة ← طبقة تكامل نظام أندرويد ← محرك النطق المحلي ← قاعدة بيانات Room المحلية."
                        } else {
                            "• Package ID: com.sharafi.offlineassistant\n" +
                                "• Zero Internet Dependency: android.permission.INTERNET is completely omitted from AndroidManifest.xml.\n" +
                                "• 7-Layer Modular Pipeline: On-Device Speech Engine → Bilingual Text Normalizer → Multi-Intent Classifier → Pluggable Module Registry → Verified Android System Executor → Local TTS → Room SQLite Storage."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.InstallMobile,
                            contentDescription = null,
                            tint = TurquoiseAccent
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isArabic) "دليل التثبيت المباشر على هاتفك الأندرويد" else "Mobile-Only Smartphone Installation Guide",
                            style = MaterialTheme.typography.titleSmall,
                            color = TurquoiseAccent,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (isArabic) {
                            "1. من متصفح هاتفك في Google AI Studio، افتح قائمة الإعدادات/التصدير (Settings / Export).\n" +
                                "2. اختر تنزيل ملف APK القابل للتثبيت (Download APK) أو تنزيل المشروع الكامل كملف مضغوط (Export ZIP).\n" +
                                "3. افتح ملف APK على هاتفك ووافق على التثبيت للاستمتاع بجميع قدرات المساعد الصوتي محلياً دون الحاجة لجهاز كمبيوتر."
                        } else {
                            "1. Directly from your Android smartphone browser in Google AI Studio, tap the Export / Settings menu.\n" +
                                "2. Choose 'Generate / Download APK' to install directly on your phone, or 'Download ZIP' for the complete Gradle source code.\n" +
                                "3. Open the downloaded APK on your phone to install SHARAFI AI with zero desktop computer required."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianDeep,
                checkedTrackColor = CyanGlow
            )
        )
    }
}
