package com.example.sharafi.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "command_history")
data class CommandHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val rawUtterance: String,
    val normalizedText: String,
    val languageCode: String, // "AR" or "EN"
    val intentSummary: String,
    val category: String,
    val executionStatus: String, // "VERIFIED_SUCCESS", "PARTIAL_SUCCESS", "AWAITING_CONFIRMATION", "NEEDS_CLARIFICATION", "RESTRICTED_ALTERNATIVE", "FAILED"
    val assistantResponse: String,
    val executionDurationMs: Long,
    val isMultiStep: Boolean = false,
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_commands")
data class CustomCommandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val triggerPhrases: String, // Comma-separated triggers in AR/EN
    val actionPipeline: String, // Natural language or semicolon-separated command chain executed through the NLU pipeline
    val description: String,
    val isEnabled: Boolean = true,
    val usageCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "assistant_settings")
data class AssistantSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val uiLanguage: String = "AR", // "AR" or "EN"
    val recognitionLanguageMode: String = "AUTO", // "AUTO", "AR", "EN"
    val voiceResponsesEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val strictOfflineRecognition: Boolean = true,
    val requireSensitiveConfirmation: Boolean = true,
    val backgroundListeningServiceEnabled: Boolean = false,
    val wakeWordPhrase: String = "يا شرافي / Hey Sharafi",
    val hapticFeedbackEnabled: Boolean = true
)
