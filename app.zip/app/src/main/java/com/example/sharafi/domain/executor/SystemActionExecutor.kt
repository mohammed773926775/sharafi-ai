package com.example.sharafi.domain.executor

import android.Manifest
import android.app.ActivityManager
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.example.sharafi.domain.nlu.ActionExecutionResult
import com.example.sharafi.domain.nlu.CommandCategory
import com.example.sharafi.domain.nlu.ExecutionOutcomeStatus
import com.example.sharafi.domain.nlu.ParsedCommandIntent
import com.example.sharafi.domain.nlu.TextNormalizer
import com.example.sharafi.service.SharafiAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class InstalledAppSummary(
    val label: String,
    val normalizedLabel: String,
    val packageName: String
)

data class DeviceCapabilitiesSnapshot(
    val hasMicrophone: Boolean,
    val recordAudioGranted: Boolean,
    val callPhoneGranted: Boolean,
    val postNotificationsGranted: Boolean,
    val hasFlashlightHardware: Boolean,
    val isTorchCurrentlyOn: Boolean,
    val dndPolicyGranted: Boolean,
    val accessibilityEnabled: Boolean,
    val installedLaunchableAppsCount: Int,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val currentVolumePercent: Int,
    val ringerModeLabelAr: String,
    val ringerModeLabelEn: String
)

class SystemActionExecutor(private val context: Context) {

    private val appContext = context.applicationContext
    private val cameraManager = appContext.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val notificationManager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    private var cachedApps: List<InstalledAppSummary> = emptyList()

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            _isTorchOn.value = enabled
        }
    }

    init {
        try {
            cameraManager?.registerTorchCallback(torchCallback, null)
        } catch (_: Exception) {
        }
    }

    fun refreshCapabilitiesSnapshot(): DeviceCapabilitiesSnapshot {
        val pm = appContext.packageManager
        val hasMic = pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)
        val hasFlash = findFlashCameraId() != null
        val recordGranted = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        val callGranted = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                appContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true

        val dndGranted = notificationManager?.isNotificationPolicyAccessGranted ?: false
        val apps = getInstalledLaunchableApps(forceRefresh = false)
        val (batteryPct, charging) = readBatteryState()
        val volPct = readMediaVolumePercent()
        val (ringerAr, ringerEn) = readRingerModeLabels()

        return DeviceCapabilitiesSnapshot(
            hasMicrophone = hasMic,
            recordAudioGranted = recordGranted,
            callPhoneGranted = callGranted,
            postNotificationsGranted = notifGranted,
            hasFlashlightHardware = hasFlash,
            isTorchCurrentlyOn = _isTorchOn.value,
            dndPolicyGranted = dndGranted,
            accessibilityEnabled = SharafiAccessibilityService.isConnected.value,
            installedLaunchableAppsCount = apps.size,
            batteryPercent = batteryPct,
            isCharging = charging,
            currentVolumePercent = volPct,
            ringerModeLabelAr = ringerAr,
            ringerModeLabelEn = ringerEn
        )
    }

    fun getInstalledLaunchableApps(forceRefresh: Boolean = false): List<InstalledAppSummary> {
        if (cachedApps.isNotEmpty() && !forceRefresh) return cachedApps
        return try {
            val pm = appContext.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            cachedApps = resolveInfos.mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
                if (label.isBlank()) return@mapNotNull null
                InstalledAppSummary(
                    label = label,
                    normalizedLabel = TextNormalizer.normalize(label),
                    packageName = pkg
                )
            }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
            cachedApps
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Executes a single validated [ParsedCommandIntent] against the Android System Integration Layer.
     */
    fun executeIntent(
        intent: ParsedCommandIntent,
        requireSensitiveConfirmation: Boolean,
        userConfirmedSensitive: Boolean = false
    ): ActionExecutionResult {
        // 1. Check if clarification is needed first
        if (intent.requiresClarification) {
            return ActionExecutionResult(
                status = ExecutionOutcomeStatus.NEEDS_CLARIFICATION,
                spokenResponseAr = intent.clarificationPromptAr ?: "هل يمكنك توضيح طلبك؟",
                spokenResponseEn = intent.clarificationPromptEn ?: "Could you please clarify your request?",
                technicalDetail = "Clarification required for ${intent.actionId}",
                category = intent.category,
                actionId = intent.actionId,
                pendingClarificationIntent = intent
            )
        }

        // 2. Check if sensitive confirmation is required
        if (intent.isSensitive && requireSensitiveConfirmation && !userConfirmedSensitive) {
            val phone = intent.parameters["phone"].orEmpty()
            val body = intent.parameters["body"].orEmpty()
            val (promptAr, promptEn) = when (intent.actionId) {
                "CALL_NUMBER" -> Pair(
                    "إجراء حساس: هل تؤكد الاتصال بالرقم $phone؟",
                    "Sensitive action: Do you confirm calling $phone?"
                )
                "SEND_SMS" -> Pair(
                    "إجراء حساس: هل تؤكد تجهيز رسالة نصية إلى $phone؟ ($body)",
                    "Sensitive action: Do you confirm preparing an SMS to $phone? ($body)"
                )
                else -> Pair(
                    "هل تؤكد تنفيذ هذا الإجراء الحساس؟",
                    "Do you confirm executing this sensitive action?"
                )
            }
            return ActionExecutionResult(
                status = ExecutionOutcomeStatus.AWAITING_CONFIRMATION,
                spokenResponseAr = promptAr,
                spokenResponseEn = promptEn,
                technicalDetail = "Awaiting explicit user confirmation for ${intent.actionId}",
                category = intent.category,
                actionId = intent.actionId,
                pendingIntentToConfirm = intent
            )
        }

        return when (intent.actionId) {
            // Security Guard
            "BLOCKED_UNSAFE_SHELL" -> ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "تم حظر الأمر: نظام شرافي يرفض تنفيذ أوامر الصدفة أو الشيفرات غير المصرح بها لحماية جهازك.",
                spokenResponseEn = "Command blocked: SHARAFI AI strictly prohibits arbitrary shell or unauthorized code execution.",
                technicalDetail = "Security validation intercepted unsafe command pattern.",
                category = CommandCategory.UNKNOWN,
                actionId = intent.actionId
            )

            // Flashlight
            "FLASHLIGHT_ON" -> executeFlashlight(targetState = true)
            "FLASHLIGHT_OFF" -> executeFlashlight(targetState = false)
            "FLASHLIGHT_TOGGLE" -> executeFlashlight(targetState = !_isTorchOn.value)

            // Audio & Volume
            "VOLUME_SET" -> {
                val targetPct = intent.parameters["level"]?.toIntOrNull() ?: 50
                executeSetVolume(targetPct)
            }
            "VOLUME_UP" -> executeStepVolume(increase = true)
            "VOLUME_DOWN" -> executeStepVolume(increase = false)
            "RINGER_SILENT" -> executeRingerMode(AudioManager.RINGER_MODE_SILENT)
            "RINGER_VIBRATE" -> executeRingerMode(AudioManager.RINGER_MODE_VIBRATE)
            "RINGER_NORMAL" -> executeRingerMode(AudioManager.RINGER_MODE_NORMAL)

            // Alarms & Timers
            "SET_ALARM" -> {
                val hour = intent.parameters["hour"]?.toIntOrNull() ?: 7
                val minute = intent.parameters["minute"]?.toIntOrNull() ?: 0
                executeSetAlarm(hour, minute)
            }
            "SET_TIMER" -> {
                val seconds = intent.parameters["seconds"]?.toIntOrNull() ?: 60
                val displayAmount = intent.parameters["displayAmount"] ?: "1"
                val unit = intent.parameters["unit"] ?: "MINUTES"
                executeSetTimer(seconds, displayAmount, unit)
            }
            "SHOW_ALARMS" -> executeShowAlarms()

            // Camera & Media
            "CAMERA_PHOTO" -> executeOpenCamera(mode = "PHOTO")
            "CAMERA_SELFIE" -> executeOpenCamera(mode = "SELFIE")
            "CAMERA_VIDEO" -> executeOpenCamera(mode = "VIDEO")
            "MEDIA_PLAY" -> executeMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY, "تشغيل الوسائط", "Media playback resumed")
            "MEDIA_PAUSE" -> executeMediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE, "إيقاف الوسائط مؤقتاً", "Media playback paused")
            "MEDIA_NEXT" -> executeMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, "الانتقال للمقطع التالي", "Skipped to next track")
            "MEDIA_PREVIOUS" -> executeMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "الرجوع للمقطع السابق", "Returned to previous track")

            // Communication
            "OPEN_DIALER" -> executeOpenDialer(null)
            "CALL_NUMBER" -> executePhoneCall(intent.parameters["phone"].orEmpty())
            "SEND_SMS" -> executeSendSms(
                phone = intent.parameters["phone"].orEmpty(),
                body = intent.parameters["body"].orEmpty()
            )

            // Telemetry
            "QUERY_BATTERY" -> executeQueryBattery()
            "QUERY_TIME_DATE" -> executeQueryTimeDate()
            "QUERY_STORAGE_RAM" -> executeQueryStorageRam()
            "QUERY_CONNECTIVITY" -> executeQueryConnectivity()
            "QUERY_DEVICE_SPECS" -> executeQueryDeviceSpecs()

            // Accessibility Navigation
            "GLOBAL_BACK", "GLOBAL_HOME", "GLOBAL_RECENTS",
            "GLOBAL_NOTIFICATIONS", "GLOBAL_QUICK_SETTINGS", "GLOBAL_LOCK_SCREEN" ->
                executeGlobalNavAction(intent.actionId)

            // Math Calculator
            "CALCULATE_EXPRESSION" -> executeMathCalculation(
                lhsStr = intent.parameters["lhs"].orEmpty(),
                op = intent.parameters["op"].orEmpty(),
                rhsStr = intent.parameters["rhs"].orEmpty()
            )

            // System Settings
            else -> {
                if (intent.actionId.startsWith("OPEN_SETTING_")) {
                    executeOpenSystemSetting(
                        target = intent.parameters["target"] ?: "MAIN_SETTINGS",
                        desiredState = intent.parameters["desiredState"] ?: "OPEN"
                    )
                } else if (intent.actionId == "OPEN_APP") {
                    executeOpenApp(intent.parameters["appQuery"].orEmpty())
                } else if (intent.actionId == "LIST_INSTALLED_APPS") {
                    executeListInstalledApps()
                } else {
                    ActionExecutionResult(
                        status = ExecutionOutcomeStatus.FAILED,
                        spokenResponseAr = "لم أتمكن من مطابقة الأمر \"${intent.rawSegment}\" مع إجراء مدعوم. يمكنك تجربة قول: شغل الفلاش، ارفع الصوت، كم نسبة البطارية، أو افتح الإعدادات.",
                        spokenResponseEn = "I could not match \"${intent.rawSegment}\" to a registered device action. Try saying: Turn on flashlight, Set volume to 80, Check battery, or Open settings.",
                        technicalDetail = "Unmatched intent: ${intent.rawSegment}",
                        category = CommandCategory.UNKNOWN,
                        actionId = intent.actionId
                    )
                }
            }
        }
    }

    private fun findFlashCameraId(): String? {
        return try {
            val cm = cameraManager ?: return null
            cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun executeFlashlight(targetState: Boolean): ActionExecutionResult {
        val camId = findFlashCameraId()
        if (camId == null || cameraManager == null) {
            return ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "تعذر تشغيل الكشاف: هذا الجهاز أو المحاكي لا يحتوي على وحدة فلاش LED خلفية مدعومة.",
                spokenResponseEn = "Flashlight unavailable: This device or emulator does not report a hardware LED flash unit.",
                technicalDetail = "CameraCharacteristics.FLASH_INFO_AVAILABLE == false on all camera IDs",
                category = CommandCategory.HARDWARE_CONTROL,
                actionId = if (targetState) "FLASHLIGHT_ON" else "FLASHLIGHT_OFF"
            )
        }

        return try {
            cameraManager.setTorchMode(camId, targetState)
            _isTorchOn.value = targetState
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = if (targetState) "تم تشغيل الكشاف الخلفي بنجاح." else "تم إطفاء الكشاف الخلفي بنجاح.",
                spokenResponseEn = if (targetState) "Rear flashlight turned ON." else "Rear flashlight turned OFF.",
                technicalDetail = "CameraManager.setTorchMode($camId, $targetState) verified.",
                category = CommandCategory.HARDWARE_CONTROL,
                actionId = if (targetState) "FLASHLIGHT_ON" else "FLASHLIGHT_OFF"
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "تعذر التحكم بالكشاف حالياً بسبب قيود الكاميرا في النظام.",
                spokenResponseEn = "Could not toggle flashlight due to system camera state.",
                technicalDetail = "Torch exception: ${e.message}",
                category = CommandCategory.HARDWARE_CONTROL,
                actionId = if (targetState) "FLASHLIGHT_ON" else "FLASHLIGHT_OFF"
            )
        }
    }

    private fun executeSetVolume(targetPercent: Int): ActionExecutionResult {
        val am = audioManager ?: return ActionExecutionResult(
            status = ExecutionOutcomeStatus.FAILED,
            spokenResponseAr = "خدمة الصوت غير متاحة حالياً.",
            spokenResponseEn = "AudioManager service is unavailable.",
            technicalDetail = "AudioManager == null",
            category = CommandCategory.AUDIO_VOLUME,
            actionId = "VOLUME_SET"
        )

        val clamped = targetPercent.coerceIn(0, 100)
        val maxMusic = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val newIndex = ((clamped / 100.0) * maxMusic).roundToInt().coerceIn(0, maxMusic)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, newIndex, AudioManager.FLAG_SHOW_UI)

        val actualPercent = readMediaVolumePercent()
        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "تم ضبط مستوى الصوت على $actualPercent بالمئة.",
            spokenResponseEn = "Media volume set to $actualPercent percent.",
            technicalDetail = "AudioManager.STREAM_MUSIC index=$newIndex/$maxMusic ($actualPercent%)",
            category = CommandCategory.AUDIO_VOLUME,
            actionId = "VOLUME_SET"
        )
    }

    private fun executeStepVolume(increase: Boolean): ActionExecutionResult {
        val am = audioManager ?: return ActionExecutionResult(
            status = ExecutionOutcomeStatus.FAILED,
            spokenResponseAr = "خدمة الصوت غير متاحة.",
            spokenResponseEn = "AudioManager unavailable.",
            technicalDetail = "AudioManager == null",
            category = CommandCategory.AUDIO_VOLUME,
            actionId = if (increase) "VOLUME_UP" else "VOLUME_DOWN"
        )

        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0)
        val newPct = readMediaVolumePercent()

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = if (increase) "تم رفع مستوى الصوت إلى $newPct بالمئة." else "تم خفض مستوى الصوت إلى $newPct بالمئة.",
            spokenResponseEn = if (increase) "Volume increased to $newPct percent." else "Volume lowered to $newPct percent.",
            technicalDetail = "Adjusted STREAM_MUSIC to $newPct%",
            category = CommandCategory.AUDIO_VOLUME,
            actionId = if (increase) "VOLUME_UP" else "VOLUME_DOWN"
        )
    }

    private fun executeRingerMode(targetMode: Int): ActionExecutionResult {
        val am = audioManager ?: return ActionExecutionResult(
            status = ExecutionOutcomeStatus.FAILED,
            spokenResponseAr = "خدمة الصوت غير متاحة.",
            spokenResponseEn = "Audio service unavailable.",
            technicalDetail = "AudioManager == null",
            category = CommandCategory.AUDIO_VOLUME,
            actionId = "RINGER_MODE"
        )

        return try {
            if (targetMode == AudioManager.RINGER_MODE_SILENT &&
                notificationManager?.isNotificationPolicyAccessGranted == false
            ) {
                // Fall back to vibrate + mute media stream and explain DND permission honestly
                am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
                return ActionExecutionResult(
                    status = ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE,
                    spokenResponseAr = "تم كتم صوت الوسائط وتفعيل وضع الاهتزاز. لتفعيل الصامت التام (عدم الإزعاج)، يرجى منح صلاحية عدم الإزعاج من شاشة الصلاحيات.",
                    spokenResponseEn = "Muted media audio and switched to Vibrate mode. For full Silent (Do Not Disturb) control, grant DND policy access in Capabilities.",
                    technicalDetail = "RINGER_MODE_VIBRATE + STREAM_MUSIC=0 (DND policy not yet granted)",
                    category = CommandCategory.AUDIO_VOLUME,
                    actionId = "RINGER_SILENT"
                )
            }

            am.ringerMode = targetMode
            if (targetMode == AudioManager.RINGER_MODE_SILENT) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            }
            val (labelAr, labelEn) = readRingerModeLabels()
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = "تم تحويل وضع الصوت إلى: $labelAr.",
                spokenResponseEn = "Audio profile switched to: $labelEn.",
                technicalDetail = "AudioManager.ringerMode verified ($labelEn)",
                category = CommandCategory.AUDIO_VOLUME,
                actionId = "RINGER_MODE"
            )
        } catch (e: SecurityException) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE,
                spokenResponseAr = "يتطلب النظام صلاحية عدم الإزعاج لتغيير وضع الصامت. سأفتح إعدادات الصوت لك.",
                spokenResponseEn = "Android requires Do Not Disturb permission for silent mode. Opening Sound settings.",
                technicalDetail = "SecurityException on ringerMode: ${e.message}",
                category = CommandCategory.AUDIO_VOLUME,
                actionId = "RINGER_MODE"
            )
        }
    }

    private fun executeOpenSystemSetting(target: String, desiredState: String): ActionExecutionResult {
        val (intentAction, nameAr, nameEn, isPanelSupported) = when (target) {
            "WIFI" -> Quadruple(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS,
                "لوحة الواي فاي",
                "Wi-Fi control panel",
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
            )
            "BLUETOOTH" -> Quadruple(Settings.ACTION_BLUETOOTH_SETTINGS, "إعدادات البلوتوث", "Bluetooth settings", false)
            "AIRPLANE" -> Quadruple(Settings.ACTION_AIRPLANE_MODE_SETTINGS, "إعدادات وضع الطيران", "Airplane Mode settings", false)
            "LOCATION" -> Quadruple(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "إعدادات الموقع GPS", "Location GPS settings", false)
            "DISPLAY" -> Quadruple(Settings.ACTION_DISPLAY_SETTINGS, "إعدادات الشاشة والسطوع", "Display & Brightness settings", false)
            "BATTERY_SAVER" -> Quadruple(Settings.ACTION_BATTERY_SAVER_SETTINGS, "إعدادات توفير البطارية", "Battery Saver settings", false)
            "STORAGE" -> Quadruple(Settings.ACTION_INTERNAL_STORAGE_SETTINGS, "إعدادات التخزين", "Storage settings", false)
            "SOUND" -> Quadruple(Settings.ACTION_SOUND_SETTINGS, "إعدادات الصوت", "Sound settings", false)
            "ACCESSIBILITY" -> Quadruple(Settings.ACTION_ACCESSIBILITY_SETTINGS, "إعدادات إمكانية الوصول", "Accessibility settings", false)
            "LANGUAGE" -> Quadruple(Settings.ACTION_LOCALE_SETTINGS, "إعدادات اللغة", "Language & Locale settings", false)
            "DATA_ROAMING" -> Quadruple(Settings.ACTION_DATA_ROAMING_SETTINGS, "إعدادات بيانات الهاتف", "Mobile Data settings", false)
            "TETHERING" -> Quadruple(Settings.ACTION_WIRELESS_SETTINGS, "إعدادات الشبكة ونقطة الاتصال", "Wireless & Hotspot settings", false)
            "SECURITY" -> Quadruple(Settings.ACTION_SECURITY_SETTINGS, "إعدادات الأمان", "Security settings", false)
            else -> Quadruple(Settings.ACTION_SETTINGS, "الإعدادات العامة للجهاز", "System Settings", false)
        }

        val launched = launchIntentSafely(Intent(intentAction)) ||
            launchIntentSafely(Intent(Settings.ACTION_SETTINGS))

        return if (launched) {
            val isToggleRequest = desiredState == "ON" || desiredState == "OFF"
            val status = if (isToggleRequest && target in listOf("WIFI", "BLUETOOTH", "AIRPLANE", "LOCATION")) {
                ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE
            } else {
                ExecutionOutcomeStatus.VERIFIED_SUCCESS
            }

            val arMsg = if (status == ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE) {
                "نظراً لسياسات أمان أندرويد، تم فتح $nameAr مباشرة لتأكيد التبديل بلمسة واحدة."
            } else {
                "تم فتح $nameAr بنجاح."
            }

            val enMsg = if (status == ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE) {
                "Due to Android OS security policies, opened $nameEn directly for one-tap toggle."
            } else {
                "Opened $nameEn."
            }

            ActionExecutionResult(
                status = status,
                spokenResponseAr = arMsg,
                spokenResponseEn = enMsg,
                technicalDetail = "Intent($intentAction) launched (panel=$isPanelSupported)",
                category = CommandCategory.SYSTEM_SETTINGS,
                actionId = "OPEN_SETTING_$target"
            )
        } else {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "تعذر فتح $nameAr على هذا الجهاز.",
                spokenResponseEn = "Could not open $nameEn on this device.",
                technicalDetail = "No Activity found for $intentAction",
                category = CommandCategory.SYSTEM_SETTINGS,
                actionId = "OPEN_SETTING_$target"
            )
        }
    }

    private fun executeSetAlarm(hour: Int, minute: Int): ActionExecutionResult {
        val formattedTime = String.format(Locale.US, "%02d:%02d", hour, minute)
        val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "SHARAFI AI")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }

        val launched = launchIntentSafely(alarmIntent)
        return if (launched) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = "تم إرسال أمر ضبط المنبه على الساعة $formattedTime إلى تطبيق الساعة.",
                spokenResponseEn = "Alarm set for $formattedTime via the system Clock application.",
                technicalDetail = "AlarmClock.ACTION_SET_ALARM ($formattedTime) dispatched.",
                category = CommandCategory.ALARMS_TIMERS,
                actionId = "SET_ALARM"
            )
        } else {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE,
                spokenResponseAr = "تم تسجيل وقت المنبه المطلوب ($formattedTime)، لكن لم يتم العثور على تطبيق منبه افتراضي مثبت في النظام.",
                spokenResponseEn = "Parsed alarm time ($formattedTime), but no system Clock app responded to ACTION_SET_ALARM on this image.",
                technicalDetail = "No package resolved AlarmClock.ACTION_SET_ALARM",
                category = CommandCategory.ALARMS_TIMERS,
                actionId = "SET_ALARM"
            )
        }
    }

    private fun executeSetTimer(seconds: Int, displayAmount: String, unit: String): ActionExecutionResult {
        val unitAr = when (unit) {
            "HOURS" -> "ساعة"
            "SECONDS" -> "ثانية"
            else -> "دقيقة"
        }
        val unitEn = unit.lowercase()

        val timerIntent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, "SHARAFI AI Timer")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }

        val launched = launchIntentSafely(timerIntent)
        return if (launched) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = "تم تشغيل مؤقت لمدة $displayAmount $unitAr.",
                spokenResponseEn = "Started a timer for $displayAmount $unitEn.",
                technicalDetail = "AlarmClock.ACTION_SET_TIMER (${seconds}s) dispatched.",
                category = CommandCategory.ALARMS_TIMERS,
                actionId = "SET_TIMER"
            )
        } else {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE,
                spokenResponseAr = "تم تجهيز مؤقت لمدة $displayAmount $unitAr، لكن تطبيق الساعة غير متاح في هذه البيئة.",
                spokenResponseEn = "Prepared timer for $displayAmount $unitEn, but no system Clock app handled ACTION_SET_TIMER.",
                technicalDetail = "No package resolved AlarmClock.ACTION_SET_TIMER",
                category = CommandCategory.ALARMS_TIMERS,
                actionId = "SET_TIMER"
            )
        }
    }

    private fun executeShowAlarms(): ActionExecutionResult {
        val launched = launchIntentSafely(Intent(AlarmClock.ACTION_SHOW_ALARMS))
        return if (launched) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = "تم فتح قائمة المنبهات.",
                spokenResponseEn = "Opened system alarms list.",
                technicalDetail = "AlarmClock.ACTION_SHOW_ALARMS launched.",
                category = CommandCategory.ALARMS_TIMERS,
                actionId = "SHOW_ALARMS"
            )
        } else {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "تعذر العثور على تطبيق المنبهات على هذا الجهاز.",
                spokenResponseEn = "Could not find a system alarms application.",
                technicalDetail = "AlarmClock.ACTION_SHOW_ALARMS unresolved.",
                category = CommandCategory.ALARMS_TIMERS,
                actionId = "SHOW_ALARMS"
            )
        }
    }

    private fun executeOpenCamera(mode: String): ActionExecutionResult {
        val intent = when (mode) {
            "VIDEO" -> Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA)
            "SELFIE" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                putExtra("android.intent.extras.CAMERA_FACING", 1)
                putExtra("android.intent.extras.LENS_FACING_FRONT", 1)
                putExtra("android.intent.extra.USE_FRONT_CAMERA", true)
            }
            else -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        }

        val launched = launchIntentSafely(intent) ||
            launchIntentSafely(Intent(MediaStore.ACTION_IMAGE_CAPTURE))

        return if (launched) {
            val (ar, en) = when (mode) {
                "VIDEO" -> Pair("تم فتح كاميرا الفيديو.", "Opened video camera.")
                "SELFIE" -> Pair("تم فتح الكاميرا الأمامية (سيلفي).", "Opened front selfie camera.")
                else -> Pair("تم فتح تطبيق الكاميرا.", "Opened camera application.")
            }
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = ar,
                spokenResponseEn = en,
                technicalDetail = "Camera intent ($mode) launched.",
                category = CommandCategory.CAMERA_MEDIA,
                actionId = "CAMERA_$mode"
            )
        } else {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "تعذر فتح تطبيق الكاميرا على هذا الجهاز.",
                spokenResponseEn = "No camera application available to handle the request.",
                technicalDetail = "MediaStore camera intent unresolved.",
                category = CommandCategory.CAMERA_MEDIA,
                actionId = "CAMERA_$mode"
            )
        }
    }

    private fun executeMediaKey(keyCode: Int, descAr: String, descEn: String): ActionExecutionResult {
        val am = audioManager ?: return ActionExecutionResult(
            status = ExecutionOutcomeStatus.FAILED,
            spokenResponseAr = "خدمة الصوت غير متاحة للتحكم بالوسائط.",
            spokenResponseEn = "Audio service unavailable for media control.",
            technicalDetail = "AudioManager == null",
            category = CommandCategory.CAMERA_MEDIA,
            actionId = "MEDIA_KEY"
        )

        val eventTime = SystemClock.uptimeMillis()
        val downEvent = KeyEvent(eventTime, eventTime, KeyEvent.ACTION_DOWN, keyCode, 0)
        val upEvent = KeyEvent(eventTime, eventTime, KeyEvent.ACTION_UP, keyCode, 0)
        am.dispatchMediaKeyEvent(downEvent)
        am.dispatchMediaKeyEvent(upEvent)

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "تم إرسال أمر $descAr إلى مشغل الوسائط النشط.",
            spokenResponseEn = "$descEn command dispatched to active media player.",
            technicalDetail = "AudioManager.dispatchMediaKeyEvent(keyCode=$keyCode)",
            category = CommandCategory.CAMERA_MEDIA,
            actionId = "MEDIA_KEY_$keyCode"
        )
    }

    private fun executeOpenDialer(phone: String?): ActionExecutionResult {
        val uri = if (phone.isNullOrBlank()) Uri.parse("tel:") else Uri.parse("tel:${Uri.encode(phone)}")
        val dialIntent = Intent(Intent.ACTION_DIAL, uri)
        val launched = launchIntentSafely(dialIntent)
        return if (launched) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = if (phone.isNullOrBlank()) "تم فتح لوحة الاتصال." else "تم فتح شاشة الاتصال بالرقم $phone.",
                spokenResponseEn = if (phone.isNullOrBlank()) "Opened phone dialer." else "Opened dialer with $phone.",
                technicalDetail = "Intent.ACTION_DIAL ($uri)",
                category = CommandCategory.COMMUNICATION,
                actionId = "OPEN_DIALER"
            )
        } else {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "لا يوجد تطبيق هاتف مثبت على هذا الجهاز.",
                spokenResponseEn = "No phone dialer app is installed on this device.",
                technicalDetail = "ACTION_DIAL unresolved",
                category = CommandCategory.COMMUNICATION,
                actionId = "OPEN_DIALER"
            )
        }
    }

    private fun executePhoneCall(phone: String): ActionExecutionResult {
        val hasCallPermission = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        if (hasCallPermission) {
            val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(phone)}"))
            if (launchIntentSafely(callIntent)) {
                return ActionExecutionResult(
                    status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                    spokenResponseAr = "جاري الاتصال بالرقم $phone بعد تأكيدك.",
                    spokenResponseEn = "Placing call to $phone following your confirmation.",
                    technicalDetail = "Intent.ACTION_CALL dispatched for $phone",
                    category = CommandCategory.COMMUNICATION,
                    actionId = "CALL_NUMBER"
                )
            }
        }

        // Safe fallback to ACTION_DIAL so the user isn't blocked if CALL_PHONE permission isn't granted
        val dialResult = executeOpenDialer(phone)
        return if (dialResult.status == ExecutionOutcomeStatus.VERIFIED_SUCCESS) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE,
                spokenResponseAr = "تم فتح لوحة الاتصال مع الرقم $phone جاهزاً. يمكنك منح صلاحية الاتصال المباشر من شاشة الصلاحيات.",
                spokenResponseEn = "Opened dialer with $phone ready. Grant CALL_PHONE permission for direct dialing.",
                technicalDetail = "Fallback to ACTION_DIAL (CALL_PHONE permission=$hasCallPermission)",
                category = CommandCategory.COMMUNICATION,
                actionId = "CALL_NUMBER",
                requiredPermission = Manifest.permission.CALL_PHONE
            )
        } else {
            dialResult
        }
    }

    private fun executeSendSms(phone: String, body: String): ActionExecutionResult {
        val smsIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}")).apply {
            putExtra("sms_body", body)
        }
        val launched = launchIntentSafely(smsIntent)
        return if (launched) {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = "تم فتح تطبيق الرسائل مع تجهيز الرسالة إلى $phone.",
                spokenResponseEn = "Opened messaging app with SMS prepared for $phone.",
                technicalDetail = "Intent.ACTION_SENDTO (smsto:$phone)",
                category = CommandCategory.COMMUNICATION,
                actionId = "SEND_SMS"
            )
        } else {
            ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "تعذر العثور على تطبيق رسائل نصية على هذا الجهاز.",
                spokenResponseEn = "Could not find an SMS messaging app on this device.",
                technicalDetail = "ACTION_SENDTO smsto unresolved",
                category = CommandCategory.COMMUNICATION,
                actionId = "SEND_SMS"
            )
        }
    }

    private fun executeQueryBattery(): ActionExecutionResult {
        val (pct, isCharging) = readBatteryState()
        val tempStr = readBatteryTempCelsius()
        val chargeStateAr = if (isCharging) "متصل بالشاحن حالياً" else "يعمل على البطارية (غير متصل بالشاحن)"
        val chargeStateEn = if (isCharging) "currently charging" else "running on battery (unplugged)"

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "نسبة شحن البطارية الحالية هي $pct بالمئة، والجهاز $chargeStateAr. درجة حرارة البطارية $tempStr درجة مئوية.",
            spokenResponseEn = "Battery level is at $pct percent, and the device is $chargeStateEn. Battery temperature is $tempStr°C.",
            technicalDetail = "BatteryManager capacity=$pct%, charging=$isCharging, temp=${tempStr}C",
            category = CommandCategory.DEVICE_TELEMETRY,
            actionId = "QUERY_BATTERY"
        )
    }

    private fun executeQueryTimeDate(): ActionExecutionResult {
        val now = Date()
        val timeAr = SimpleDateFormat("hh:mm a", Locale("ar")).format(now)
        val dateAr = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")).format(now)
        val timeEn = SimpleDateFormat("hh:mm a", Locale.US).format(now)
        val dateEn = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US).format(now)

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "الساعة الآن $timeAr، وتاريخ اليوم هو $dateAr.",
            spokenResponseEn = "The current time is $timeEn, and today is $dateEn.",
            technicalDetail = "System clock: $timeEn | $dateEn",
            category = CommandCategory.DEVICE_TELEMETRY,
            actionId = "QUERY_TIME_DATE"
        )
    }

    private fun executeQueryStorageRam(): ActionExecutionResult {
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalBytes = stat.blockSizeLong * stat.blockCountLong
        val availBytes = stat.blockSizeLong * stat.availableBlocksLong
        val totalGb = String.format(Locale.US, "%.1f", totalBytes / (1024.0 * 1024.0 * 1024.0))
        val availGb = String.format(Locale.US, "%.1f", availBytes / (1024.0 * 1024.0 * 1024.0))

        val actMgr = appContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actMgr?.getMemoryInfo(memInfo)
        val availRamGb = String.format(Locale.US, "%.1f", memInfo.availMem / (1024.0 * 1024.0 * 1024.0))
        val totalRamGb = String.format(Locale.US, "%.1f", memInfo.totalMem / (1024.0 * 1024.0 * 1024.0))

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "مساحة التخزين المتبقية هي $availGb جيجابايت من أصل $totalGb جيجابايت. والذاكرة العشوائية المتاحة $availRamGb جيجابايت من أصل $totalRamGb جيجابايت.",
            spokenResponseEn = "Available internal storage is $availGb GB out of $totalGb GB. Free RAM is $availRamGb GB out of $totalRamGb GB.",
            technicalDetail = "Storage: $availGb/$totalGb GB | RAM: $availRamGb/$totalRamGb GB",
            category = CommandCategory.DEVICE_TELEMETRY,
            actionId = "QUERY_STORAGE_RAM"
        )
    }

    private fun executeQueryConnectivity(): ActionExecutionResult {
        val wifiMgr = appContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val wifiEnabled = try {
            wifiMgr?.isWifiEnabled == true
        } catch (_: Exception) {
            false
        }

        val btMgr = appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val btEnabled = try {
            btMgr?.adapter?.isEnabled == true
        } catch (_: Exception) {
            false
        }

        val airplaneOn = Settings.Global.getInt(
            appContext.contentResolver,
            Settings.Global.AIRPLANE_MODE_ON,
            0
        ) != 0

        val wifiAr = if (wifiEnabled) "مفعل" else "مغلق"
        val btAr = if (btEnabled) "مفعل" else "مغلق"
        val airAr = if (airplaneOn) "مفعل" else "مغلق"

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "تقرير الاتصال المحلي: الواي فاي $wifiAr، البلوتوث $btAr، ووضع الطيران $airAr. يعمل شرافي بدون أي اتصال بالإنترنت.",
            spokenResponseEn = "Local connectivity report: Wi-Fi is ${if (wifiEnabled) "ON" else "OFF"}, Bluetooth is ${if (btEnabled) "ON" else "OFF"}, Airplane mode is ${if (airplaneOn) "ON" else "OFF"}. SHARAFI AI operates 100% offline.",
            technicalDetail = "WiFi=$wifiEnabled | BT=$btEnabled | Airplane=$airplaneOn",
            category = CommandCategory.DEVICE_TELEMETRY,
            actionId = "QUERY_CONNECTIVITY"
        )
    }

    private fun executeQueryDeviceSpecs(): ActionExecutionResult {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        val androidVer = Build.VERSION.RELEASE
        val sdkInt = Build.VERSION.SDK_INT
        val cores = Runtime.getRuntime().availableProcessors()

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "أنت تستخدم جهاز $manufacturer $model بنظام أندرويد $androidVer (مستوى الواجهة $sdkInt) ومعالج بـ $cores أنوية. مساعد شرافي يعمل محلياً بالكامل على جهازك.",
            spokenResponseEn = "Device is $manufacturer $model running Android $androidVer (API $sdkInt) with $cores CPU cores. SHARAFI AI runs 100% locally on-device.",
            technicalDetail = "$manufacturer $model | Android $androidVer (SDK $sdkInt) | $cores cores",
            category = CommandCategory.DEVICE_TELEMETRY,
            actionId = "QUERY_DEVICE_SPECS"
        )
    }

    private fun executeGlobalNavAction(actionId: String): ActionExecutionResult {
        val a11yService = SharafiAccessibilityService.instance
        if (a11yService != null) {
            val ok = a11yService.performSystemAction(actionId)
            if (ok) {
                return ActionExecutionResult(
                    status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                    spokenResponseAr = "تم تنفيذ إجراء التنقل عبر خدمة الوصول المحلية بنجاح.",
                    spokenResponseEn = "Executed global system navigation action via local Accessibility bridge.",
                    technicalDetail = "SharafiAccessibilityService.performSystemAction($actionId) == true",
                    category = CommandCategory.ACCESSIBILITY_NAV,
                    actionId = actionId
                )
            }
        }

        // Fallback when Accessibility Service is not yet enabled by the user
        if (actionId == "GLOBAL_HOME") {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (launchIntentSafely(homeIntent)) {
                return ActionExecutionResult(
                    status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                    spokenResponseAr = "تم الانتقال إلى الشاشة الرئيسية.",
                    spokenResponseEn = "Navigated to the device Home screen.",
                    technicalDetail = "Intent.CATEGORY_HOME launched",
                    category = CommandCategory.ACCESSIBILITY_NAV,
                    actionId = actionId
                )
            }
        }

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE,
            spokenResponseAr = "لتنفيذ هذا الإجراء (${actionId.removePrefix("GLOBAL_")}) صوتياً من أي مكان، يرجى تفعيل خدمة إمكانية الوصول الخاصة بـ SHARAFI AI من إعدادات النظام.",
            spokenResponseEn = "To execute ${actionId.removePrefix("GLOBAL_")} by voice system-wide, please enable the SHARAFI AI Accessibility Service in Android Settings.",
            technicalDetail = "SharafiAccessibilityService not connected; user opt-in required.",
            category = CommandCategory.ACCESSIBILITY_NAV,
            actionId = actionId
        )
    }

    private fun executeMathCalculation(lhsStr: String, op: String, rhsStr: String): ActionExecutionResult {
        val a = lhsStr.toDoubleOrNull() ?: 0.0
        val b = rhsStr.toDoubleOrNull() ?: 0.0

        if ((op == "/" || op == "÷") && b == 0.0) {
            return ActionExecutionResult(
                status = ExecutionOutcomeStatus.FAILED,
                spokenResponseAr = "لا يمكن القسمة على صفر.",
                spokenResponseEn = "Division by zero is undefined.",
                technicalDetail = "$a / 0",
                category = CommandCategory.UTILITY_CALC,
                actionId = "CALCULATE_EXPRESSION"
            )
        }

        val result = when (op) {
            "+", "plus" -> a + b
            "-", "minus" -> a - b
            "*", "x", "×" -> a * b
            "/", "÷" -> a / b
            else -> a + b
        }

        val formatted = if (result % 1.0 == 0.0) {
            result.toLong().toString()
        } else {
            String.format(Locale.US, "%.2f", result)
        }

        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "نتيجة العملية الحسابية هي $formatted.",
            spokenResponseEn = "The calculated result is $formatted.",
            technicalDetail = "$lhsStr $op $rhsStr = $formatted",
            category = CommandCategory.UTILITY_CALC,
            actionId = "CALCULATE_EXPRESSION"
        )
    }

    private fun executeOpenApp(rawQuery: String): ActionExecutionResult {
        val normalizedQuery = TextNormalizer.normalize(rawQuery)

        // Check well-known bilingual system & popular app aliases first
        val aliasSystemIntents = mapOf(
            "الاعدادات" to Intent(Settings.ACTION_SETTINGS),
            "الضبط" to Intent(Settings.ACTION_SETTINGS),
            "settings" to Intent(Settings.ACTION_SETTINGS),
            "الكاميرا" to Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            "كاميرا" to Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            "camera" to Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            "الساعه" to Intent(AlarmClock.ACTION_SHOW_ALARMS),
            "المنبه" to Intent(AlarmClock.ACTION_SHOW_ALARMS),
            "clock" to Intent(AlarmClock.ACTION_SHOW_ALARMS),
            "الهاتف" to Intent(Intent.ACTION_DIAL),
            "الاتصال" to Intent(Intent.ACTION_DIAL),
            "phone" to Intent(Intent.ACTION_DIAL),
            "dialer" to Intent(Intent.ACTION_DIAL),
            "المتصفح" to Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            "كروم" to Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            "browser" to Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            "chrome" to Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com")).addCategory(Intent.CATEGORY_BROWSABLE),
            "الحاسبه" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR),
            "اله حاسبه" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR),
            "calculator" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR),
            "التقويم" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR),
            "calendar" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR),
            "الرسائل" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            "messages" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            "جهات الاتصال" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS),
            "الاسماء" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS),
            "contacts" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS),
            "المعرض" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            "الصور" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            "gallery" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            "photos" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY),
            "الخرائط" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS),
            "maps" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS),
            "الملفات" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_FILES),
            "files" to Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_FILES)
        )

        // 1. Search installed launchable packages first
        val installed = getInstalledLaunchableApps(forceRefresh = true)
        val bilingualPackageHints = mapOf(
            "واتساب" to listOf("whatsapp"),
            "يوتيوب" to listOf("youtube"),
            "تليجرام" to listOf("telegram"),
            "انستقرام" to listOf("instagram"),
            "فيسبوك" to listOf("facebook"),
            "كروم" to listOf("chrome", "browser"),
            "الرسائل" to listOf("messaging", "mms", "messages"),
            "الحاسبه" to listOf("calculator", "calc"),
            "الساعه" to listOf("deskclock", "clock"),
            "الكاميرا" to listOf("camera"),
            "الاعدادات" to listOf("settings"),
            "الضبط" to listOf("settings"),
            "الملفات" to listOf("documentsui", "files"),
            "الخرائط" to listOf("maps")
        )

        val matchedApp = installed.firstOrNull { app ->
            app.normalizedLabel == normalizedQuery ||
                app.normalizedLabel.contains(normalizedQuery) ||
                normalizedQuery.contains(app.normalizedLabel) ||
                app.packageName.lowercase().contains(normalizedQuery) ||
                bilingualPackageHints[normalizedQuery]?.any { hint ->
                    app.packageName.lowercase().contains(hint) || app.normalizedLabel.contains(hint)
                } == true
        }

        if (matchedApp != null) {
            val launchIntent = appContext.packageManager.getLaunchIntentForPackage(matchedApp.packageName)
            if (launchIntent != null && launchIntentSafely(launchIntent)) {
                return ActionExecutionResult(
                    status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                    spokenResponseAr = "تم فتح تطبيق ${matchedApp.label} بنجاح.",
                    spokenResponseEn = "Launched ${matchedApp.label} successfully.",
                    technicalDetail = "PackageManager.getLaunchIntentForPackage(${matchedApp.packageName})",
                    category = CommandCategory.APP_MANAGEMENT,
                    actionId = "OPEN_APP"
                )
            }
        }

        // 2. Fallback to standard Android category/system selector intents
        val aliasIntent = aliasSystemIntents.entries.firstOrNull { (key, _) ->
            normalizedQuery == key || normalizedQuery.contains(key)
        }?.value

        if (aliasIntent != null && launchIntentSafely(aliasIntent)) {
            return ActionExecutionResult(
                status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
                spokenResponseAr = "تم فتح $rawQuery بنجاح.",
                spokenResponseEn = "Opened $rawQuery successfully.",
                technicalDetail = "Launched system alias intent for '$rawQuery'",
                category = CommandCategory.APP_MANAGEMENT,
                actionId = "OPEN_APP"
            )
        }

        val sampleApps = installed.take(4).joinToString("، ") { it.label }.ifBlank { "Settings, Clock, Camera" }
        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.FAILED,
            spokenResponseAr = "لم يتم العثور على تطبيق باسم \"$rawQuery\" مثبت على هذا الجهاز. من التطبيقات المتاحة حالياً: $sampleApps.",
            spokenResponseEn = "Application \"$rawQuery\" is not installed on this device. Available apps include: $sampleApps.",
            technicalDetail = "Package query '$normalizedQuery' matched 0 of ${installed.size} launchable apps",
            category = CommandCategory.APP_MANAGEMENT,
            actionId = "OPEN_APP"
        )
    }

    private fun executeListInstalledApps(): ActionExecutionResult {
        val apps = getInstalledLaunchableApps(forceRefresh = true)
        val preview = apps.take(8).joinToString("، ") { it.label }
        return ActionExecutionResult(
            status = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
            spokenResponseAr = "يوجد ${apps.size} تطبيق قابل للتشغيل على جهازك، منها: $preview.",
            spokenResponseEn = "Found ${apps.size} launchable applications on your device, including: $preview.",
            technicalDetail = "Total launchable packages=${apps.size}",
            category = CommandCategory.APP_MANAGEMENT,
            actionId = "LIST_INSTALLED_APPS"
        )
    }

    private fun launchIntentSafely(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun readBatteryState(): Pair<Int, Boolean> {
        return try {
            val bm = appContext.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)?.takeIf { it in 0..100 } ?: 85
            val sticky = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = sticky?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            Pair(pct, charging)
        } catch (_: Exception) {
            Pair(100, false)
        }
    }

    private fun readBatteryTempCelsius(): String {
        return try {
            val sticky = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenths = sticky?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 280) ?: 280
            String.format(Locale.US, "%.1f", tenths / 10.0)
        } catch (_: Exception) {
            "28.0"
        }
    }

    private fun readMediaVolumePercent(): Int {
        return try {
            val am = audioManager ?: return 50
            val current = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            ((current.toDouble() / max.toDouble()) * 100.0).roundToInt().coerceIn(0, 100)
        } catch (_: Exception) {
            50
        }
    }

    private fun readRingerModeLabels(): Pair<String, String> {
        return when (audioManager?.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> Pair("صامت", "Silent")
            AudioManager.RINGER_MODE_VIBRATE -> Pair("اهتزاز", "Vibrate")
            else -> Pair("عام (رنين)", "Normal Ring")
        }
    }

    private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
