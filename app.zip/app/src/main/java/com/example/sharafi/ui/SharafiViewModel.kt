package com.example.sharafi.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.sharafi.data.AssistantSettingsEntity
import com.example.sharafi.data.CommandHistoryEntity
import com.example.sharafi.data.CustomCommandEntity
import com.example.sharafi.data.SharafiDatabase
import com.example.sharafi.data.SharafiRepository
import com.example.sharafi.domain.executor.DeviceCapabilitiesSnapshot
import com.example.sharafi.domain.executor.InstalledAppSummary
import com.example.sharafi.domain.executor.SystemActionExecutor
import com.example.sharafi.domain.nlu.ActionExecutionResult
import com.example.sharafi.domain.nlu.AssistantLanguage
import com.example.sharafi.domain.nlu.CommandCategory
import com.example.sharafi.domain.nlu.CommandModulePlugin
import com.example.sharafi.domain.nlu.ExecutionOutcomeStatus
import com.example.sharafi.domain.nlu.ParsedCommandIntent
import com.example.sharafi.domain.nlu.SharafiNluEngine
import com.example.sharafi.domain.nlu.TextNormalizer
import com.example.sharafi.service.OfflineSpeechEngine
import com.example.sharafi.service.OfflineTtsEngine
import com.example.sharafi.service.SharafiVoiceService
import com.example.sharafi.service.SpeechListeningState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SharafiScreen {
    COMMAND_CENTER,
    HISTORY,
    CUSTOM_MACROS,
    CAPABILITIES,
    SETTINGS_INFO
}

data class ActiveExecutionConsoleState(
    val lastSpokenOrTypedCommand: String = "",
    val detectedLanguage: AssistantLanguage = AssistantLanguage.AR,
    val stepResults: List<ActionExecutionResult> = emptyList(),
    val combinedAssistantResponse: String = "",
    val overallStatus: ExecutionOutcomeStatus = ExecutionOutcomeStatus.VERIFIED_SUCCESS,
    val matchedMacroTitle: String? = null,
    val executionDurationMs: Long = 0L,
    val pendingSensitiveConfirmation: ParsedCommandIntent? = null,
    val pendingClarification: ParsedCommandIntent? = null
)

class SharafiViewModel(application: Application) : AndroidViewModel(application) {

    private val database = SharafiDatabase.getInstance(application)
    private val repository = SharafiRepository(database.sharafiDao())
    val nluEngine = SharafiNluEngine()
    val actionExecutor = SystemActionExecutor(application)
    val ttsEngine = OfflineTtsEngine(application)
    val speechEngine = OfflineSpeechEngine(application) { finalTranscript ->
        processVoiceOrTextCommand(finalTranscript)
    }

    private val _currentScreen = MutableStateFlow(SharafiScreen.COMMAND_CENTER)
    val currentScreen: StateFlow<SharafiScreen> = _currentScreen.asStateFlow()

    val settingsState: StateFlow<AssistantSettingsEntity> = repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AssistantSettingsEntity()
        )

    val historyState: StateFlow<List<CommandHistoryEntity>> = repository.historyFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val customCommandsState: StateFlow<List<CustomCommandEntity>> = repository.customCommandsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _consoleState = MutableStateFlow(
        ActiveExecutionConsoleState(
            lastSpokenOrTypedCommand = "مرحباً بك في SHARAFI AI — المساعد الصوتي الذكي بدون إنترنت",
            detectedLanguage = AssistantLanguage.AR,
            combinedAssistantResponse = "اضغط على زر الميكروفون المتوهج أو اختر أمراً فورياً بالأسفل للتحكم الكامل بجهازك باللغتين العربية والإنجليزية دون أي اتصال سحابي.",
            overallStatus = ExecutionOutcomeStatus.VERIFIED_SUCCESS
        )
    )
    val consoleState: StateFlow<ActiveExecutionConsoleState> = _consoleState.asStateFlow()

    private val _capabilitiesSnapshot = MutableStateFlow(actionExecutor.refreshCapabilitiesSnapshot())
    val capabilitiesSnapshot: StateFlow<DeviceCapabilitiesSnapshot> = _capabilitiesSnapshot.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppSummary>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppSummary>> = _installedApps.asStateFlow()

    private val _historyFilterCategory = MutableStateFlow<String?>(null)
    val historyFilterCategory: StateFlow<String?> = _historyFilterCategory.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultsSeeded()
            refreshCapabilities()
            _installedApps.value = actionExecutor.getInstalledLaunchableApps(forceRefresh = true)
        }
    }

    fun navigateTo(screen: SharafiScreen) {
        _currentScreen.value = screen
        if (screen == SharafiScreen.CAPABILITIES || screen == SharafiScreen.COMMAND_CENTER) {
            refreshCapabilities()
        }
    }

    fun refreshCapabilities() {
        _capabilitiesSnapshot.value = actionExecutor.refreshCapabilitiesSnapshot()
        _installedApps.value = actionExecutor.getInstalledLaunchableApps(forceRefresh = false)
    }

    fun setHistoryCategoryFilter(categoryName: String?) {
        _historyFilterCategory.value = categoryName
    }

    fun toggleUiLanguage() {
        viewModelScope.launch {
            repository.updateSettings { current ->
                val nextLang = if (current.uiLanguage == "AR") "EN" else "AR"
                current.copy(uiLanguage = nextLang)
            }
        }
    }

    fun setRecognitionLanguageMode(mode: String) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(recognitionLanguageMode = mode) }
        }
    }

    fun setVoiceResponsesEnabled(enabled: Boolean) {
        viewModelScope.launch {
            if (!enabled) ttsEngine.stopSpeaking()
            repository.updateSettings { it.copy(voiceResponsesEnabled = enabled) }
        }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(speechRate = rate.coerceIn(0.6f, 1.8f)) }
        }
    }

    fun setSpeechPitch(pitch: Float) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(speechPitch = pitch.coerceIn(0.6f, 1.6f)) }
        }
    }

    fun setStrictOfflineRecognition(strict: Boolean) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(strictOfflineRecognition = strict) }
        }
    }

    fun setRequireSensitiveConfirmation(require: Boolean) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(requireSensitiveConfirmation = require) }
        }
    }

    fun setHapticFeedbackEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateSettings { it.copy(hapticFeedbackEnabled = enabled) }
        }
    }

    fun setWakeWordPhrase(phrase: String) {
        viewModelScope.launch {
            if (phrase.isNotBlank()) {
                repository.updateSettings { it.copy(wakeWordPhrase = phrase.trim()) }
            }
        }
    }

    fun toggleBackgroundVoiceService(enable: Boolean) {
        viewModelScope.launch {
            val app = getApplication<Application>()
            val serviceIntent = Intent(app, SharafiVoiceService::class.java)
            try {
                if (enable) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        app.startForegroundService(serviceIntent)
                    } else {
                        app.startService(serviceIntent)
                    }
                } else {
                    serviceIntent.action = SharafiVoiceService.ACTION_STOP_SERVICE
                    app.startService(serviceIntent)
                }
                repository.updateSettings { it.copy(backgroundListeningServiceEnabled = enable) }
            } catch (_: Exception) {
                repository.updateSettings { it.copy(backgroundListeningServiceEnabled = false) }
            }
        }
    }

    fun startOrStopMicrophoneListening() {
        val currentListenState = speechEngine.listeningState.value
        if (currentListenState == SpeechListeningState.LISTENING ||
            currentListenState == SpeechListeningState.PROCESSING
        ) {
            speechEngine.stopListening()
            return
        }

        ttsEngine.stopSpeaking()
        triggerHapticTick()
        val settings = settingsState.value
        val uiLang = if (settings.uiLanguage == "AR") AssistantLanguage.AR else AssistantLanguage.EN
        speechEngine.startOfflineListening(
            languageMode = settings.recognitionLanguageMode,
            uiLanguage = uiLang,
            strictOffline = settings.strictOfflineRecognition
        )
    }

    /**
     * Core pipeline: Analyzes any spoken or typed Arabic/English command offline,
     * routes multi-action chains, checks sensitive confirmation / clarification,
     * executes verified Android APIs, logs to Room, and speaks the verified result via offline TTS.
     */
    fun processVoiceOrTextCommand(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            triggerHapticTick()

            val settings = repository.getSettingsOnce()
            val enabledMacros = repository.getEnabledCustomCommands()
            val pendingClarification = _consoleState.value.pendingClarification

            val analysis = nluEngine.analyzeUtterance(
                rawUtterance = trimmed,
                enabledCustomCommands = enabledMacros,
                pendingClarification = pendingClarification
            )

            if (analysis.matchedCustomCommandId != null) {
                repository.incrementCustomCommandUsage(analysis.matchedCustomCommandId)
            }

            val results = mutableListOf<ActionExecutionResult>()
            var pendingConfirm: ParsedCommandIntent? = null
            var nextClarification: ParsedCommandIntent? = null

            for (intent in analysis.intents) {
                val execResult = actionExecutor.executeIntent(
                    intent = intent,
                    requireSensitiveConfirmation = settings.requireSensitiveConfirmation,
                    userConfirmedSensitive = false
                )
                results.add(execResult)
                if (execResult.pendingIntentToConfirm != null && pendingConfirm == null) {
                    pendingConfirm = execResult.pendingIntentToConfirm
                }
                if (execResult.pendingClarificationIntent != null && nextClarification == null) {
                    nextClarification = execResult.pendingClarificationIntent
                }
            }

            val durationMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
            val lang = analysis.detectedLanguage

            val combinedResponse = results.joinToString(
                separator = if (lang == AssistantLanguage.AR) " ، ثم " else " | Then: "
            ) { it.responseFor(lang) }

            val overallStatus = when {
                pendingConfirm != null -> ExecutionOutcomeStatus.AWAITING_CONFIRMATION
                nextClarification != null -> ExecutionOutcomeStatus.NEEDS_CLARIFICATION
                results.all { it.status == ExecutionOutcomeStatus.VERIFIED_SUCCESS } -> ExecutionOutcomeStatus.VERIFIED_SUCCESS
                results.any { it.status == ExecutionOutcomeStatus.VERIFIED_SUCCESS || it.status == ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE } ->
                    if (results.any { it.status == ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE }) {
                        ExecutionOutcomeStatus.RESTRICTED_ALTERNATIVE
                    } else {
                        ExecutionOutcomeStatus.PARTIAL_SUCCESS
                    }
                else -> ExecutionOutcomeStatus.FAILED
            }

            _consoleState.value = ActiveExecutionConsoleState(
                lastSpokenOrTypedCommand = trimmed,
                detectedLanguage = lang,
                stepResults = results,
                combinedAssistantResponse = combinedResponse,
                overallStatus = overallStatus,
                matchedMacroTitle = analysis.matchedCustomCommandTitle,
                executionDurationMs = durationMs,
                pendingSensitiveConfirmation = pendingConfirm,
                pendingClarification = nextClarification
            )

            refreshCapabilities()

            // Persist to local Room Command History
            val primaryCategory = analysis.intents.firstOrNull()?.category ?: CommandCategory.UNKNOWN
            val intentSummary = analysis.intents.joinToString(" -> ") { it.actionId }
            repository.logCommandHistory(
                CommandHistoryEntity(
                    rawUtterance = trimmed,
                    normalizedText = TextNormalizer.normalize(trimmed),
                    languageCode = lang.code,
                    intentSummary = intentSummary,
                    category = primaryCategory.name,
                    executionStatus = overallStatus.name,
                    assistantResponse = combinedResponse,
                    executionDurationMs = durationMs,
                    isMultiStep = analysis.intents.size > 1
                )
            )

            // Speak verified response via local offline TTS
            ttsEngine.speakOffline(
                text = combinedResponse,
                language = lang,
                enabled = settings.voiceResponsesEnabled,
                rate = settings.speechRate,
                pitch = settings.speechPitch
            )
        }
    }

    fun confirmPendingSensitiveAction() {
        val pending = _consoleState.value.pendingSensitiveConfirmation ?: return
        viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            val settings = repository.getSettingsOnce()
            val execResult = actionExecutor.executeIntent(
                intent = pending,
                requireSensitiveConfirmation = settings.requireSensitiveConfirmation,
                userConfirmedSensitive = true
            )
            val durationMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
            val lang = pending.language
            val responseText = execResult.responseFor(lang)

            _consoleState.value = _consoleState.value.copy(
                stepResults = listOf(execResult),
                combinedAssistantResponse = responseText,
                overallStatus = execResult.status,
                executionDurationMs = durationMs,
                pendingSensitiveConfirmation = null
            )

            repository.logCommandHistory(
                CommandHistoryEntity(
                    rawUtterance = "${pending.rawSegment} [Confirmed]",
                    normalizedText = pending.normalizedSegment,
                    languageCode = lang.code,
                    intentSummary = "${pending.actionId}_CONFIRMED",
                    category = pending.category.name,
                    executionStatus = execResult.status.name,
                    assistantResponse = responseText,
                    executionDurationMs = durationMs
                )
            )

            ttsEngine.speakOffline(
                text = responseText,
                language = lang,
                enabled = settings.voiceResponsesEnabled,
                rate = settings.speechRate,
                pitch = settings.speechPitch
            )
        }
    }

    fun cancelPendingSensitiveAction() {
        val current = _consoleState.value
        val lang = current.detectedLanguage
        val cancelMsg = if (lang == AssistantLanguage.AR) {
            "تم إلغاء الإجراء الحساس بناءً على طلبك."
        } else {
            "Sensitive action cancelled as requested."
        }
        _consoleState.value = current.copy(
            combinedAssistantResponse = cancelMsg,
            overallStatus = ExecutionOutcomeStatus.FAILED,
            pendingSensitiveConfirmation = null,
            pendingClarification = null
        )
    }

    fun dismissClarification() {
        _consoleState.value = _consoleState.value.copy(pendingClarification = null)
    }

    // History actions
    fun toggleHistoryFavorite(item: CommandHistoryEntity) {
        viewModelScope.launch {
            repository.toggleHistoryFavorite(item.id, !item.isFavorite)
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteHistoryItem(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
        }
    }

    // Custom Command CRUD
    fun saveCustomCommand(
        id: Long = 0L,
        title: String,
        triggerPhrases: String,
        actionPipeline: String,
        description: String
    ) {
        if (title.isBlank() || triggerPhrases.isBlank() || actionPipeline.isBlank()) return
        viewModelScope.launch {
            repository.saveCustomCommand(
                CustomCommandEntity(
                    id = id,
                    title = title.trim(),
                    triggerPhrases = triggerPhrases.trim(),
                    actionPipeline = actionPipeline.trim(),
                    description = description.trim().ifBlank { actionPipeline.trim() }
                )
            )
        }
    }

    fun toggleCustomCommandEnabled(command: CustomCommandEntity) {
        viewModelScope.launch {
            repository.setCustomCommandEnabled(command.id, !command.isEnabled)
        }
    }

    fun deleteCustomCommand(id: Long) {
        viewModelScope.launch {
            repository.deleteCustomCommand(id)
        }
    }

    fun testVoiceSynthesisSample() {
        viewModelScope.launch {
            val settings = repository.getSettingsOnce()
            val isAr = settings.uiLanguage == "AR"
            val sample = if (isAr) {
                "مرحباً، أنا شرافي، مساعدك الصوتي الذكي الذي يعمل محلياً بالكامل بدون إنترنت."
            } else {
                "Hello, I am SHARAFI AI, your fully offline voice assistant operating 100 percent locally on your device."
            }
            ttsEngine.speakOffline(
                text = sample,
                language = if (isAr) AssistantLanguage.AR else AssistantLanguage.EN,
                enabled = true,
                rate = settings.speechRate,
                pitch = settings.speechPitch
            )
        }
    }

    fun getRegisteredModules(): List<CommandModulePlugin> = nluEngine.getRegisteredPlugins()

    private fun triggerHapticTick() {
        if (!settingsState.value.hapticFeedbackEnabled) return
        try {
            val app = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            }
        } catch (_: Exception) {
        }
    }

    override fun onCleared() {
        speechEngine.destroy()
        ttsEngine.shutdown()
        super.onCleared()
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SharafiViewModel(application) as T
        }
    }
}
